"""
ocr_server.py - License Plate Detection & Recognition
Uses YOLOv8 for plate detection + EasyOCR for text reading
Run: python ocr_server.py
"""

import re
import base64
import logging

import cv2
import numpy as np
import easyocr
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from ultralytics import YOLO

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── App Setup ─────────────────────────────────────────────────────────────────
app = FastAPI(
    title="License Plate OCR API",
    description="YOLO + EasyOCR based license plate recognition",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Load Models (on startup) ──────────────────────────────────────────────────
reader = None
yolo_model = None

@app.on_event("startup")
async def load_models():
    global reader, yolo_model

    logger.info("Loading EasyOCR model...")
    reader = easyocr.Reader(['en'], gpu=False)
    logger.info("EasyOCR loaded ✅")

    logger.info("Loading YOLOv8 model...")

    # Fix for PyTorch 2.6+ which changed weights_only default to True
    import torch
    import torch.serialization
    try:
        from ultralytics.nn.tasks import DetectionModel, SegmentationModel, PoseModel, ClassificationModel
        torch.serialization.add_safe_globals([
            DetectionModel, SegmentationModel, PoseModel, ClassificationModel
        ])
        logger.info("PyTorch safe globals configured ✅")
    except Exception as e:
        logger.warning(f"Could not set safe globals (may not be needed): {e}")

    try:
        yolo_model = YOLO("yolov8n.pt")
        logger.info("YOLOv8 loaded ✅")
    except Exception as e:
        logger.error(f"YOLO load failed: {e}")
        # Try alternative loading with weights_only=False patch
        import torch
        original_load = torch.load
        def patched_load(*args, **kwargs):
            kwargs['weights_only'] = False
            return original_load(*args, **kwargs)
        torch.load = patched_load
        yolo_model = YOLO("yolov8n.pt")
        torch.load = original_load
        logger.info("YOLOv8 loaded with compatibility patch ✅")

    logger.info("🚀 OCR Server ready on port 8000")


# ── Helpers ───────────────────────────────────────────────────────────────────
def clean_plate_text(text: str) -> str:
    cleaned = re.sub(r'[^A-Z0-9]', '', text.upper())
    return cleaned


def preprocess_image(img: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    gray = cv2.fastNlMeansDenoising(gray, h=30)
    thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 11, 2
    )
    return thresh


def detect_plate_region(img: np.ndarray, model) -> np.ndarray:
    try:
        results = model(img, verbose=False)
        best_crop = None
        best_conf = 0.0
        for result in results:
            for box in result.boxes:
                conf = float(box.conf[0])
                if conf > best_conf:
                    best_conf = conf
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    plate_y1 = y1 + int((y2 - y1) * 0.75)
                    best_crop = img[plate_y1:y2, x1:x2]
        return best_crop
    except Exception as e:
        logger.warning(f"YOLO detection failed: {e}")
        return None


def run_ocr(img: np.ndarray) -> list:
    global reader
    try:
        results = reader.readtext(img)
        parsed = [
            {"text": clean_plate_text(text), "confidence": round(conf, 3)}
            for (_, text, conf) in results
            if len(clean_plate_text(text)) >= 4
        ]
        parsed.sort(key=lambda x: x["confidence"], reverse=True)
        return parsed
    except Exception as e:
        logger.error(f"OCR failed: {e}")
        return []


def process_image(img: np.ndarray) -> dict:
    """Full pipeline: YOLO detect → OCR read → return best result"""
    global yolo_model

    ocr_results = []

    # Try YOLO region first
    if yolo_model is not None:
        plate_region = detect_plate_region(img, yolo_model)
        if plate_region is not None and plate_region.size > 0:
            logger.info("YOLO detected region, running OCR on crop")
            preprocessed = preprocess_image(plate_region)
            ocr_results = run_ocr(preprocessed)

    # Fallback: full image preprocessed
    if not ocr_results:
        logger.info("Trying full image OCR")
        preprocessed_full = preprocess_image(img)
        ocr_results = run_ocr(preprocessed_full)

    # Fallback: raw image
    if not ocr_results:
        logger.info("Trying raw image OCR")
        ocr_results = run_ocr(img)

    if not ocr_results:
        return {"success": False, "plate_number": None, "confidence": 0,
                "message": "Could not detect plate. Try a clearer photo in good lighting.",
                "all_results": []}

    best = ocr_results[0]
    logger.info(f"Detected: {best['text']} ({best['confidence']})")
    return {"success": True, "plate_number": best["text"],
            "confidence": best["confidence"],
            "message": f"Plate detected: {best['text']}",
            "all_results": ocr_results[:5]}


# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "easyocr": reader is not None, "yolo": yolo_model is not None}


@app.post("/detect-plate")
async def detect_plate(file: UploadFile = File(...)):
    contents = await file.read()
    if not contents:
        raise HTTPException(status_code=400, detail="Empty file")
    nparr = np.frombuffer(contents, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(status_code=400, detail="Could not decode image")
    return process_image(img)


@app.post("/detect-plate-base64")
async def detect_plate_base64(payload: dict):
    image_data = payload.get("image")
    if not image_data:
        raise HTTPException(status_code=400, detail="No image data provided")
    if "," in image_data:
        image_data = image_data.split(",")[1]
    try:
        img_bytes = base64.b64decode(image_data)
        nparr = np.frombuffer(img_bytes, np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image: {str(e)}")
    if img is None:
        raise HTTPException(status_code=400, detail="Could not decode image")
    return process_image(img)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ocr_server:app", host="0.0.0.0", port=8000, reload=False)
