// user.routes.js
const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const { protect, authorize } = require('../middleware/auth.middleware');
const { validateRegisterUser } = require('../middleware/validation.middleware');

router.use(protect, authorize('admin'));
router.get('/', userController.getAllUsers);
router.post('/', validateRegisterUser, userController.createUser);
router.put('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);

module.exports = router;
