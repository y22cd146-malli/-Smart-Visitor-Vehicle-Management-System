/**
 * auth.routes.js
 */
const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { protect } = require('../middleware/auth.middleware');
const { validateLogin } = require('../middleware/validation.middleware');

router.post('/login', validateLogin, authController.login);
router.get('/me', protect, authController.getMe);
router.put('/change-password', protect, authController.changePassword);
router.post('/seed-admin', authController.seedAdmin); // One-time setup

module.exports = router;
