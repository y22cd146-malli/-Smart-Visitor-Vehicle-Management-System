// analytics.routes.js
const express = require('express');
const router = express.Router();
const analyticsController = require('../controllers/analytics.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.use(protect, authorize('admin', 'security'));
router.get('/dashboard', analyticsController.getDashboardStats);
router.get('/daily-trend', analyticsController.getDailyTrend);
router.get('/monthly-trend', analyticsController.getMonthlyTrend);
router.get('/peak-hours', analyticsController.getPeakHours);
router.get('/purpose-stats', analyticsController.getPurposeStats);
router.get('/status-distribution', analyticsController.getStatusDistribution);

module.exports = router;
