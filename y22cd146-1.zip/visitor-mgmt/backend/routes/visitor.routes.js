/**
 * visitor.routes.js
 */
const express = require('express');
const router = express.Router();
const visitorController = require('../controllers/visitor.controller');
const { protect, authorize } = require('../middleware/auth.middleware');
const {
  validateVisitorRegistration,
  validateStatusUpdate,
  validatePagination,
} = require('../middleware/validation.middleware');

// Public routes (no auth required)
router.post('/register', validateVisitorRegistration, visitorController.registerVisitor);
router.get('/verify/:token', visitorController.getVisitorByToken);

// Protected routes (admin + security)
router.get('/', protect, authorize('admin', 'security'), validatePagination, visitorController.getAllVisitors);
router.get('/export', protect, authorize('admin', 'security'), visitorController.exportCSV);
router.get('/:id', protect, authorize('admin', 'security'), visitorController.getVisitor);
router.patch('/:id/status', protect, authorize('admin', 'security'), validateStatusUpdate, visitorController.updateStatus);
router.delete('/:id', protect, authorize('admin'), visitorController.deleteVisitor);

// QR scan (security staff)
router.post('/scan/qr', protect, authorize('admin', 'security'), visitorController.scanQR);

module.exports = router;
