// activity.routes.js
const express = require('express');
const router = express.Router();
const { getActivityLogs } = require('../controllers/activity.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.get('/', protect, authorize('admin'), getActivityLogs);
module.exports = router;
