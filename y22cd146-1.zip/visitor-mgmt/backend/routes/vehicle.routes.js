// vehicle.routes.js
const express = require('express');
const router = express.Router();
const vehicleController = require('../controllers/vehicle.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.post('/capture', protect, authorize('admin', 'security'), vehicleController.captureVehicleNumber);
router.get('/search', protect, authorize('admin', 'security'), vehicleController.searchByVehicle);

module.exports = router;
