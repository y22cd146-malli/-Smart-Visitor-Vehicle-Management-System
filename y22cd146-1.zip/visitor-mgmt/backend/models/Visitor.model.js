/**
 * Visitor.model.js - Visitor Schema
 * Tracks all visitor registration, entry, and exit data
 */

const mongoose = require('mongoose');

const visitorSchema = new mongoose.Schema(
  {
    // ── Identity ────────────────────────────────────────────────────────────
    name: {
      type: String,
      required: [true, 'Visitor name is required'],
      trim: true,
      maxlength: [100, 'Name cannot exceed 100 characters'],
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      trim: true,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, 'Please enter a valid email'],
    },
    phone: {
      type: String,
      required: [true, 'Phone number is required'],
      trim: true,
      match: [/^[0-9+\-\s()]{7,20}$/, 'Please enter a valid phone number'],
    },
    photo: {
      type: String, // Base64 or URL
      default: null,
    },
    idProofType: {
      type: String,
      enum: ['aadhar', 'passport', 'driving_license', 'voter_id', 'pan', 'other'],
      default: 'other',
    },
    idProofNumber: {
      type: String,
      trim: true,
    },

    // ── Visit Details ────────────────────────────────────────────────────────
    purpose: {
      type: String,
      required: [true, 'Purpose of visit is required'],
      trim: true,
      maxlength: [500, 'Purpose cannot exceed 500 characters'],
    },
    hostName: {
      type: String,
      required: [true, 'Host name is required'],
      trim: true,
    },
    hostEmail: {
      type: String,
      trim: true,
      lowercase: true,
    },
    hostDepartment: {
      type: String,
      trim: true,
    },
    numberOfVisitors: {
      type: Number,
      default: 1,
      min: [1, 'Must have at least 1 visitor'],
      max: [50, 'Cannot exceed 50 visitors in a group'],
    },

    // ── Vehicle Information ──────────────────────────────────────────────────
    hasVehicle: {
      type: Boolean,
      default: false,
    },
    vehicleNumber: {
      type: String,
      trim: true,
      uppercase: true,
    },
    vehicleType: {
      type: String,
      enum: ['car', 'motorcycle', 'truck', 'van', 'bicycle', 'other'],
    },
    vehicleNumberCaptured: {
      type: Boolean,
      default: false,
    }, // AI capture flag

    // ── Status & Timestamps ──────────────────────────────────────────────────
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected', 'inside', 'exited'],
      default: 'pending',
      index: true,
    },
    entryTime: { type: Date, default: null },
    exitTime: { type: Date, default: null },
    expectedCheckoutTime: { type: Date, default: null },

    // ── QR Code ─────────────────────────────────────────────────────────────
    qrCode: {
      type: String, // Base64 PNG of QR code
      default: null,
    },
    qrToken: {
      type: String, // Unique token embedded in QR
      unique: true,
      sparse: true,
    },

    // ── Notifications ────────────────────────────────────────────────────────
    hostNotified: {
      type: Boolean,
      default: false,
    },
    notificationSentAt: { type: Date },

    // ── Approval ────────────────────────────────────────────────────────────
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    rejectedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
    },
    rejectionReason: { type: String },

    // ── Security badge number ─────────────────────────────────────────────────
    badgeNumber: { type: String },

    // ── Metadata ─────────────────────────────────────────────────────────────
    registeredVia: {
      type: String,
      enum: ['qr', 'manual', 'walk-in'],
      default: 'qr',
    },
    ipAddress: { type: String },
    userAgent: { type: String },
  },
  {
    timestamps: true, // Adds createdAt, updatedAt
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// ── Indexes ───────────────────────────────────────────────────────────────────
visitorSchema.index({ createdAt: -1 });
visitorSchema.index({ status: 1, createdAt: -1 });
visitorSchema.index({ email: 1 });
visitorSchema.index({ vehicleNumber: 1 });
visitorSchema.index({ qrToken: 1 });
visitorSchema.index({ hostEmail: 1 });

// ── Virtuals ──────────────────────────────────────────────────────────────────
visitorSchema.virtual('duration').get(function () {
  if (this.entryTime && this.exitTime) {
    const diff = this.exitTime - this.entryTime;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    return hours > 0 ? `${hours}h ${minutes % 60}m` : `${minutes}m`;
  }
  return null;
});

module.exports = mongoose.model('Visitor', visitorSchema);
