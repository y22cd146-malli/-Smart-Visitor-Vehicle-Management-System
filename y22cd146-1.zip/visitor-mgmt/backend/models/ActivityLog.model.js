/**
 * ActivityLog.model.js - System Activity Log Schema
 * Records all significant actions for auditing and reporting
 */

const mongoose = require('mongoose');

const activityLogSchema = new mongoose.Schema(
  {
    action: {
      type: String,
      required: true,
      enum: [
        'VISITOR_REGISTERED',
        'VISITOR_APPROVED',
        'VISITOR_REJECTED',
        'VISITOR_ENTRY',
        'VISITOR_EXIT',
        'QR_SCANNED',
        'VEHICLE_CAPTURED',
        'HOST_NOTIFIED',
        'USER_LOGIN',
        'USER_LOGOUT',
        'USER_CREATED',
        'USER_UPDATED',
        'REPORT_DOWNLOADED',
        'SYSTEM_ERROR',
      ],
      index: true,
    },
    description: {
      type: String,
      required: true,
    },
    performedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
    performedByName: { type: String }, // denormalized for fast reads
    visitorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Visitor',
      default: null,
      index: true,
    },
    visitorName: { type: String }, // denormalized
    metadata: {
      type: mongoose.Schema.Types.Mixed, // flexible extra data
      default: {},
    },
    ipAddress: { type: String },
    severity: {
      type: String,
      enum: ['info', 'warning', 'error', 'critical'],
      default: 'info',
    },
  },
  {
    timestamps: true,
  }
);

// TTL index: auto-delete logs older than 90 days
activityLogSchema.index({ createdAt: 1 }, { expireAfterSeconds: 90 * 24 * 60 * 60 });
activityLogSchema.index({ createdAt: -1 });
activityLogSchema.index({ action: 1, createdAt: -1 });

module.exports = mongoose.model('ActivityLog', activityLogSchema);
