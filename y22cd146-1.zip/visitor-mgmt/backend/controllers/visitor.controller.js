/**
 * visitor.controller.js - Visitor CRUD & Lifecycle Management
 */

const { v4: uuidv4 } = require('uuid');
const QRCode = require('qrcode');
const Visitor = require('../models/Visitor.model');
const ActivityLog = require('../models/ActivityLog.model');
const { asyncHandler } = require('../middleware/error.middleware');
const { emitVisitorUpdate, emitToVisitor } = require('../config/socket.config');
const { sendHostNotificationEmail } = require('../utils/email.util');
const { logActivity } = require('../utils/activityLogger.util');

// ── Register Visitor ──────────────────────────────────────────────────────────
exports.registerVisitor = asyncHandler(async (req, res) => {
  const {
    name, email, phone, purpose, hostName, hostEmail, hostDepartment,
    numberOfVisitors, hasVehicle, vehicleNumber, vehicleType,
    idProofType, idProofNumber, photo,
  } = req.body;

  const qrToken = uuidv4();
  const qrData = `${process.env.QR_BASE_URL}/verify/${qrToken}`;

  const qrCode = await QRCode.toDataURL(qrData, {
    errorCorrectionLevel: 'H',
    type: 'image/png',
    margin: 2,
    color: { dark: '#1a1a2e', light: '#ffffff' },
  });

  const visitor = await Visitor.create({
    name, email, phone, purpose, hostName, hostEmail, hostDepartment,
    numberOfVisitors: numberOfVisitors || 1,
    hasVehicle: hasVehicle || false,
    vehicleNumber: hasVehicle ? vehicleNumber : undefined,
    vehicleType: hasVehicle ? vehicleType : undefined,
    idProofType, idProofNumber, photo,
    qrToken, qrCode,
    registeredVia: req.body.registeredVia || 'qr',
    ipAddress: req.ip,
    userAgent: req.headers['user-agent'],
  });

  // Emit real-time event
  const io = req.app.get('io');
  emitVisitorUpdate(io, 'visitor:new', {
    visitor: sanitizeVisitor(visitor),
    message: `New visitor registered: ${visitor.name}`,
  });

  // Log activity
  await logActivity({
    action: 'VISITOR_REGISTERED',
    description: `Visitor ${visitor.name} registered for ${visitor.hostName}`,
    visitorId: visitor._id,
    visitorName: visitor.name,
    ipAddress: req.ip,
  });

  // Send host notification email (async - don't block response)
  if (hostEmail) {
    sendHostNotificationEmail(visitor).then(async (sent) => {
      if (sent) {
        await Visitor.findByIdAndUpdate(visitor._id, {
          hostNotified: true,
          notificationSentAt: new Date(),
        });
      }
    }).catch(console.error);
  }

  res.status(201).json({
    success: true,
    message: 'Registration successful! Please wait for approval.',
    data: {
      visitorId: visitor._id,
      qrCode: visitor.qrCode,
      qrToken: visitor.qrToken,
      status: visitor.status,
      name: visitor.name,
    },
  });
});

// ── Get All Visitors ──────────────────────────────────────────────────────────
exports.getAllVisitors = asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, status, search, startDate, endDate, sortBy = 'createdAt', order = 'desc' } = req.query;

  const filter = {};
  if (status && status !== 'all') filter.status = status;
  if (startDate || endDate) {
    filter.createdAt = {};
    if (startDate) filter.createdAt.$gte = new Date(startDate);
    if (endDate) { const end = new Date(endDate); end.setHours(23, 59, 59, 999); filter.createdAt.$lte = end; }
  }
  if (search) {
    const regex = new RegExp(search, 'i');
    filter.$or = [{ name: regex }, { email: regex }, { phone: regex }, { vehicleNumber: regex }, { hostName: regex }];
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);
  const [visitors, total] = await Promise.all([
    Visitor.find(filter).sort({ [sortBy]: order === 'asc' ? 1 : -1 }).skip(skip).limit(parseInt(limit)).populate('approvedBy', 'name email').lean(),
    Visitor.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: visitors,
    pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / parseInt(limit)) },
  });
});

// ── Get Single Visitor ────────────────────────────────────────────────────────
exports.getVisitor = asyncHandler(async (req, res) => {
  const visitor = await Visitor.findById(req.params.id).populate('approvedBy', 'name email role');
  if (!visitor) return res.status(404).json({ success: false, message: 'Visitor not found' });
  res.json({ success: true, data: visitor });
});

// ── Get Visitor by QR Token ───────────────────────────────────────────────────
exports.getVisitorByToken = asyncHandler(async (req, res) => {
  const visitor = await Visitor.findOne({ qrToken: req.params.token }).lean();
  if (!visitor) return res.status(404).json({ success: false, message: 'Invalid QR code' });
  res.json({ success: true, data: sanitizeVisitor(visitor) });
});

// ── Update Visitor Status ─────────────────────────────────────────────────────
exports.updateStatus = asyncHandler(async (req, res) => {
  const { status, rejectionReason, vehicleNumber, badgeNumber } = req.body;

  const visitor = await Visitor.findById(req.params.id);
  if (!visitor) return res.status(404).json({ success: false, message: 'Visitor not found' });

  // Allowed status transitions
  const allowedTransitions = {
    pending: ['approved', 'rejected'],
    approved: ['inside', 'rejected'],
    inside: ['exited'],
    rejected: [],
    exited: [],
  };

  if (!allowedTransitions[visitor.status]?.includes(status)) {
    return res.status(400).json({
      success: false,
      message: `Cannot change status from '${visitor.status}' to '${status}'`,
    });
  }

  const updates = { status };

  // Set timestamps based on status
  if (status === 'approved') {
    updates.approvedBy = req.user._id;
    if (badgeNumber) updates.badgeNumber = badgeNumber;
  }
  if (status === 'rejected') {
    updates.rejectedBy = req.user._id;
    updates.rejectionReason = rejectionReason || 'Rejected by admin';
  }
  if (status === 'inside') {
    updates.entryTime = new Date(); // ✅ Record exact entry timestamp
    if (vehicleNumber) updates.vehicleNumber = vehicleNumber;
  }
  if (status === 'exited') {
    updates.exitTime = new Date(); // ✅ Record exact exit timestamp
  }

  const updatedVisitor = await Visitor.findByIdAndUpdate(
    req.params.id, updates, { new: true, runValidators: true }
  ).populate('approvedBy', 'name email');

  // Real-time broadcast
  const io = req.app.get('io');
  emitVisitorUpdate(io, 'visitor:updated', {
    visitor: sanitizeVisitor(updatedVisitor),
    message: `${visitor.name}'s status updated to ${status}`,
  });

  // Notify visitor on their status page
  emitToVisitor(io, visitor._id.toString(), 'status:changed', {
    status: updatedVisitor.status,
    message: getStatusMessage(status),
  });

  // Log activity
  await logActivity({
    action: `VISITOR_${status.toUpperCase()}`,
    description: `${visitor.name} status → ${status} by ${req.user.name}`,
    performedBy: req.user._id,
    performedByName: req.user.name,
    visitorId: visitor._id,
    visitorName: visitor.name,
    ipAddress: req.ip,
  });

  res.json({
    success: true,
    message: `Status updated to ${status}`,
    data: updatedVisitor,
  });
});

// ── Scan QR ───────────────────────────────────────────────────────────────────
exports.scanQR = asyncHandler(async (req, res) => {
  const { qrToken } = req.body;
  const visitor = await Visitor.findOne({ qrToken });
  if (!visitor) return res.status(404).json({ success: false, message: 'Invalid QR code' });

  if (visitor.status === 'pending') {
    return res.status(400).json({ success: false, message: 'Visitor not yet approved.', visitor: sanitizeVisitor(visitor) });
  }
  if (visitor.status === 'rejected') {
    return res.status(400).json({ success: false, message: 'Visitor has been rejected.', visitor: sanitizeVisitor(visitor) });
  }
  if (visitor.status === 'exited') {
    return res.status(400).json({ success: false, message: 'Visitor has already exited.', visitor: sanitizeVisitor(visitor) });
  }

  const io = req.app.get('io');

  if (visitor.status === 'approved') {
    visitor.status = 'inside';
    visitor.entryTime = new Date(); // ✅ Timestamp on QR scan entry
    await visitor.save();

    emitVisitorUpdate(io, 'visitor:updated', {
      visitor: sanitizeVisitor(visitor),
      message: `${visitor.name} has entered the premises`,
    });

    await logActivity({
      action: 'VISITOR_ENTRY',
      description: `QR scanned. ${visitor.name} entered at ${visitor.entryTime.toLocaleTimeString()}`,
      performedBy: req.user?._id,
      performedByName: req.user?.name,
      visitorId: visitor._id,
      visitorName: visitor.name,
      ipAddress: req.ip,
    });
  }

  res.json({ success: true, message: 'QR verified successfully', data: sanitizeVisitor(visitor) });
});

// ── CSV Export ────────────────────────────────────────────────────────────────
exports.exportCSV = asyncHandler(async (req, res) => {
  const { startDate, endDate, status } = req.query;
  const filter = {};
  if (status && status !== 'all') filter.status = status;
  if (startDate || endDate) {
    filter.createdAt = {};
    if (startDate) filter.createdAt.$gte = new Date(startDate);
    if (endDate) filter.createdAt.$lte = new Date(endDate);
  }

  const visitors = await Visitor.find(filter).sort({ createdAt: -1 }).limit(10000).lean();

  const headers = ['Name', 'Email', 'Phone', 'Host', 'Purpose', 'Status', 'Vehicle Number', 'Registered At', 'Entry Time', 'Exit Time', 'Duration (mins)'];

  const rows = visitors.map((v) => {
    const duration = v.entryTime && v.exitTime
      ? Math.round((new Date(v.exitTime) - new Date(v.entryTime)) / 60000)
      : '';
    return [
      v.name, v.email, v.phone, v.hostName, v.purpose, v.status,
      v.vehicleNumber || '',
      v.createdAt ? new Date(v.createdAt).toLocaleString('en-IN') : '',
      v.entryTime ? new Date(v.entryTime).toLocaleString('en-IN') : '',
      v.exitTime ? new Date(v.exitTime).toLocaleString('en-IN') : '',
      duration,
    ];
  });

  const csv = [headers, ...rows].map((r) => r.map((c) => `"${c}"`).join(',')).join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="visitors_${Date.now()}.csv"`);
  res.send(csv);
});

// ── Delete Visitor ────────────────────────────────────────────────────────────
exports.deleteVisitor = asyncHandler(async (req, res) => {
  const visitor = await Visitor.findByIdAndDelete(req.params.id);
  if (!visitor) return res.status(404).json({ success: false, message: 'Visitor not found' });
  const io = req.app.get('io');
  emitVisitorUpdate(io, 'visitor:deleted', { visitorId: req.params.id });
  res.json({ success: true, message: 'Visitor deleted' });
});

// ── Helpers ───────────────────────────────────────────────────────────────────
const sanitizeVisitor = (visitor) => {
  const v = visitor.toObject ? visitor.toObject() : { ...visitor };
  delete v.qrToken;
  return v;
};

const getStatusMessage = (status) => {
  const messages = {
    approved: 'Your visit has been approved! Proceed to reception.',
    rejected: 'Your visit request has been rejected.',
    inside: 'You have checked in successfully.',
    exited: 'You have been checked out. Thank you for visiting!',
  };
  return messages[status] || `Status updated to ${status}`;
};
