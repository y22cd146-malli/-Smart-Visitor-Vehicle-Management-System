/**
 * activity.controller.js - Activity Log Retrieval
 */

const ActivityLog = require('../models/ActivityLog.model');
const { asyncHandler } = require('../middleware/error.middleware');

exports.getActivityLogs = asyncHandler(async (req, res) => {
  const { page = 1, limit = 50, action, severity, startDate, endDate } = req.query;
  const filter = {};

  if (action) filter.action = action;
  if (severity) filter.severity = severity;
  if (startDate || endDate) {
    filter.createdAt = {};
    if (startDate) filter.createdAt.$gte = new Date(startDate);
    if (endDate) filter.createdAt.$lte = new Date(endDate);
  }

  const skip = (parseInt(page) - 1) * parseInt(limit);

  const [logs, total] = await Promise.all([
    ActivityLog.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean(),
    ActivityLog.countDocuments(filter),
  ]);

  res.json({
    success: true,
    data: logs,
    pagination: { total, page: parseInt(page), limit: parseInt(limit), pages: Math.ceil(total / parseInt(limit)) },
  });
});
