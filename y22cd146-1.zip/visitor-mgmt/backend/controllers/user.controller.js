/**
 * user.controller.js - User (Staff) Management
 */

const User = require('../models/User.model');
const { asyncHandler } = require('../middleware/error.middleware');
const { logActivity } = require('../utils/activityLogger.util');

// ── Get All Users (Admin only) ────────────────────────────────────────────────
exports.getAllUsers = asyncHandler(async (req, res) => {
  const users = await User.find().select('-password').sort({ createdAt: -1 });
  res.json({ success: true, data: users });
});

// ── Create User (Admin only) ──────────────────────────────────────────────────
exports.createUser = asyncHandler(async (req, res) => {
  const { name, email, password, role, phone, department, employeeId } = req.body;

  const existing = await User.findOne({ email });
  if (existing) {
    return res.status(400).json({ success: false, message: 'User with this email already exists' });
  }

  const user = await User.create({ name, email, password, role, phone, department, employeeId });

  await logActivity({
    action: 'USER_CREATED',
    description: `New ${role} account created for ${name} by ${req.user.name}`,
    performedBy: req.user._id,
    performedByName: req.user.name,
    ipAddress: req.ip,
  });

  res.status(201).json({
    success: true,
    message: 'User created successfully',
    data: { id: user._id, name, email, role },
  });
});

// ── Update User ───────────────────────────────────────────────────────────────
exports.updateUser = asyncHandler(async (req, res) => {
  const { name, phone, department, employeeId, isActive, role } = req.body;

  // Prevent non-admins from updating roles
  if (req.user.role !== 'admin' && role) {
    return res.status(403).json({ success: false, message: 'Only admins can change roles' });
  }

  const user = await User.findByIdAndUpdate(
    req.params.id,
    { name, phone, department, employeeId, isActive, role },
    { new: true, runValidators: true }
  ).select('-password');

  if (!user) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  await logActivity({
    action: 'USER_UPDATED',
    description: `User ${user.name} updated by ${req.user.name}`,
    performedBy: req.user._id,
    performedByName: req.user.name,
    ipAddress: req.ip,
  });

  res.json({ success: true, message: 'User updated', data: user });
});

// ── Delete User (Admin only) ──────────────────────────────────────────────────
exports.deleteUser = asyncHandler(async (req, res) => {
  if (req.params.id === req.user._id.toString()) {
    return res.status(400).json({ success: false, message: 'Cannot delete your own account' });
  }

  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  res.json({ success: true, message: 'User deleted successfully' });
});
