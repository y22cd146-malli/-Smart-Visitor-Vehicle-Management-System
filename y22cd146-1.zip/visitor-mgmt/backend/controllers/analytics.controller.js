/**
 * analytics.controller.js - Dashboard Statistics & Charts
 */

const Visitor = require('../models/Visitor.model');
const ActivityLog = require('../models/ActivityLog.model');
const { asyncHandler } = require('../middleware/error.middleware');

// ── Main Dashboard Stats ──────────────────────────────────────────────────────
exports.getDashboardStats = asyncHandler(async (req, res) => {
  const now = new Date();
  const startOfDay = new Date(now.setHours(0, 0, 0, 0));
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const [
    totalVisitors,
    todayVisitors,
    monthlyVisitors,
    pendingCount,
    insideCount,
    rejectedCount,
    exitedToday,
  ] = await Promise.all([
    Visitor.countDocuments(),
    Visitor.countDocuments({ createdAt: { $gte: startOfDay } }),
    Visitor.countDocuments({ createdAt: { $gte: startOfMonth } }),
    Visitor.countDocuments({ status: 'pending' }),
    Visitor.countDocuments({ status: 'inside' }),
    Visitor.countDocuments({ status: 'rejected' }),
    Visitor.countDocuments({ status: 'exited', exitTime: { $gte: startOfDay } }),
  ]);

  res.json({
    success: true,
    data: {
      totalVisitors,
      todayVisitors,
      monthlyVisitors,
      pendingCount,
      insideCount,
      rejectedCount,
      exitedToday,
      approvedToday: todayVisitors - pendingCount,
    },
  });
});

// ── Daily Visitor Trend (Last 7 days) ─────────────────────────────────────────
exports.getDailyTrend = asyncHandler(async (req, res) => {
  const days = parseInt(req.query.days) || 7;
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const trend = await Visitor.aggregate([
    { $match: { createdAt: { $gte: startDate } } },
    {
      $group: {
        _id: {
          year: { $year: '$createdAt' },
          month: { $month: '$createdAt' },
          day: { $dayOfMonth: '$createdAt' },
        },
        count: { $sum: 1 },
        approved: { $sum: { $cond: [{ $in: ['$status', ['approved', 'inside', 'exited']] }, 1, 0] } },
        rejected: { $sum: { $cond: [{ $eq: ['$status', 'rejected'] }, 1, 0] } },
      },
    },
    { $sort: { '_id.year': 1, '_id.month': 1, '_id.day': 1 } },
  ]);

  const formatted = trend.map((item) => ({
    date: `${item._id.year}-${String(item._id.month).padStart(2, '0')}-${String(item._id.day).padStart(2, '0')}`,
    total: item.count,
    approved: item.approved,
    rejected: item.rejected,
  }));

  res.json({ success: true, data: formatted });
});

// ── Monthly Visitor Trend (Last 12 months) ────────────────────────────────────
exports.getMonthlyTrend = asyncHandler(async (req, res) => {
  const startDate = new Date();
  startDate.setMonth(startDate.getMonth() - 11);
  startDate.setDate(1);
  startDate.setHours(0, 0, 0, 0);

  const trend = await Visitor.aggregate([
    { $match: { createdAt: { $gte: startDate } } },
    {
      $group: {
        _id: { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
        count: { $sum: 1 },
      },
    },
    { $sort: { '_id.year': 1, '_id.month': 1 } },
  ]);

  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const formatted = trend.map((item) => ({
    month: `${months[item._id.month - 1]} ${item._id.year}`,
    count: item.count,
  }));

  res.json({ success: true, data: formatted });
});

// ── Peak Hours Analysis ───────────────────────────────────────────────────────
exports.getPeakHours = asyncHandler(async (req, res) => {
  const days = parseInt(req.query.days) || 30;
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - days);

  const hourly = await Visitor.aggregate([
    { $match: { createdAt: { $gte: startDate } } },
    {
      $group: {
        _id: { hour: { $hour: '$createdAt' } },
        count: { $sum: 1 },
      },
    },
    { $sort: { '_id.hour': 1 } },
  ]);

  const formatted = Array.from({ length: 24 }, (_, h) => {
    const found = hourly.find((item) => item._id.hour === h);
    return {
      hour: `${String(h).padStart(2, '0')}:00`,
      count: found ? found.count : 0,
    };
  });

  res.json({ success: true, data: formatted });
});

// ── Purpose Distribution ──────────────────────────────────────────────────────
exports.getPurposeStats = asyncHandler(async (req, res) => {
  const stats = await Visitor.aggregate([
    {
      $group: {
        _id: '$purpose',
        count: { $sum: 1 },
      },
    },
    { $sort: { count: -1 } },
    { $limit: 10 },
  ]);

  res.json({ success: true, data: stats.map((s) => ({ purpose: s._id, count: s.count })) });
});

// ── Status Distribution ───────────────────────────────────────────────────────
exports.getStatusDistribution = asyncHandler(async (req, res) => {
  const stats = await Visitor.aggregate([
    { $group: { _id: '$status', count: { $sum: 1 } } },
  ]);

  const result = { pending: 0, approved: 0, inside: 0, exited: 0, rejected: 0 };
  stats.forEach((s) => { if (result[s._id] !== undefined) result[s._id] = s.count; });

  res.json({ success: true, data: result });
});
