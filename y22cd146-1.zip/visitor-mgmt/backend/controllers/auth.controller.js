/**
 * auth.controller.js - Authentication (Login, Logout, Me)
 */

const jwt = require('jsonwebtoken');
const User = require('../models/User.model');
const { asyncHandler } = require('../middleware/error.middleware');
const { logActivity } = require('../utils/activityLogger.util');

// Generate JWT
const signToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d',
  });
};

// ── Login ─────────────────────────────────────────────────────────────────────
exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  // Find user with password field
  const user = await User.findOne({ email }).select('+password');

  if (!user || !(await user.comparePassword(password))) {
    return res.status(401).json({ success: false, message: 'Invalid email or password' });
  }

  if (!user.isActive) {
    return res.status(401).json({ success: false, message: 'Account deactivated. Contact admin.' });
  }

  // Update last login
  user.lastLogin = new Date();
  user.lastLoginIp = req.ip;
  await user.save({ validateBeforeSave: false });

  const token = signToken(user._id, user.role);

  await logActivity({
    action: 'USER_LOGIN',
    description: `${user.name} (${user.role}) logged in`,
    performedBy: user._id,
    performedByName: user.name,
    ipAddress: req.ip,
  });

  res.json({
    success: true,
    message: 'Login successful',
    token,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      avatar: user.avatar,
    },
  });
});

// ── Get Current User ──────────────────────────────────────────────────────────
exports.getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, data: req.user });
});

// ── Change Password ───────────────────────────────────────────────────────────
exports.changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;

  const user = await User.findById(req.user._id).select('+password');

  if (!(await user.comparePassword(currentPassword))) {
    return res.status(401).json({ success: false, message: 'Current password is incorrect' });
  }

  user.password = newPassword;
  await user.save();

  res.json({ success: true, message: 'Password changed successfully' });
});

// ── Seed Admin (first-time setup) ────────────────────────────────────────────
exports.seedAdmin = asyncHandler(async (req, res) => {
  const count = await User.countDocuments({ role: 'admin' });
  if (count > 0) {
    return res.status(400).json({ success: false, message: 'Admin already exists' });
  }

  const admin = await User.create({
    name: 'System Admin',
    email: 'admin@visitormanagement.com',
    password: 'Admin@123456',
    role: 'admin',
    department: 'Administration',
  });

  res.status(201).json({
    success: true,
    message: 'Admin account created. Change password immediately!',
    credentials: { email: admin.email, password: 'Admin@123456' },
  });
});
