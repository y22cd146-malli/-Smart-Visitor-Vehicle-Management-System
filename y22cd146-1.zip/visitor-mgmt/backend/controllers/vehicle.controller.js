/**
 * vehicle.controller.js - Vehicle Number Capture (Mock AI Module)
 */

const Visitor = require('../models/Visitor.model');
const { asyncHandler } = require('../middleware/error.middleware');
const { emitVisitorUpdate } = require('../config/socket.config');
const { logActivity } = require('../utils/activityLogger.util');

/**
 * Mock AI Vehicle Number Recognition
 * In production, replace with actual OCR service (Google Vision, AWS Rekognition, etc.)
 */
const mockAIVehicleRecognition = async (imageBase64) => {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 800));

  // Mock: extract plate number from simulated AI result
  const mockPlates = ['MH12AB1234', 'DL10XX9876', 'KA03MN5678', 'TN09YZ2345', 'GJ01CD7890'];
  const randomPlate = mockPlates[Math.floor(Math.random() * mockPlates.length)];

  return {
    success: true,
    plateNumber: randomPlate,
    confidence: (0.85 + Math.random() * 0.13).toFixed(2),
    processingTime: '0.8s',
    engine: 'MockAI-v1.0',
  };
};

// ── Capture Vehicle Number via AI ─────────────────────────────────────────────
exports.captureVehicleNumber = asyncHandler(async (req, res) => {
  const { imageBase64, visitorId } = req.body;

  if (!imageBase64) {
    return res.status(400).json({ success: false, message: 'Image data is required' });
  }

  // Run AI recognition
  const aiResult = await mockAIVehicleRecognition(imageBase64);

  if (!aiResult.success) {
    return res.status(422).json({
      success: false,
      message: 'Could not detect vehicle number. Please enter manually.',
    });
  }

  // If visitorId provided, update visitor record
  if (visitorId) {
    const visitor = await Visitor.findByIdAndUpdate(
      visitorId,
      {
        vehicleNumber: aiResult.plateNumber,
        vehicleNumberCaptured: true,
        hasVehicle: true,
      },
      { new: true }
    );

    if (visitor) {
      const io = req.app.get('io');
      emitVisitorUpdate(io, 'visitor:updated', { visitor });

      await logActivity({
        action: 'VEHICLE_CAPTURED',
        description: `Vehicle ${aiResult.plateNumber} captured via AI for visitor ${visitor.name}`,
        performedBy: req.user?._id,
        performedByName: req.user?.name,
        visitorId: visitor._id,
        visitorName: visitor.name,
        metadata: { confidence: aiResult.confidence, engine: aiResult.engine },
        ipAddress: req.ip,
      });
    }
  }

  res.json({
    success: true,
    message: 'Vehicle number captured successfully',
    data: aiResult,
  });
});

// ── Search by Vehicle Number ──────────────────────────────────────────────────
exports.searchByVehicle = asyncHandler(async (req, res) => {
  const { plate } = req.query;
  if (!plate) {
    return res.status(400).json({ success: false, message: 'Vehicle number required' });
  }

  const visitors = await Visitor.find({
    vehicleNumber: new RegExp(plate, 'i'),
  })
    .sort({ createdAt: -1 })
    .limit(10)
    .lean();

  res.json({ success: true, data: visitors, count: visitors.length });
});
