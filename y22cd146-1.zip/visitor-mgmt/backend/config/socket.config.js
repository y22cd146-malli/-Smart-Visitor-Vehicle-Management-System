/**
 * socket.config.js - Socket.IO Configuration & Event Handlers
 */

const jwt = require('jsonwebtoken');

/**
 * Socket event namespaces and rooms:
 * - 'admin-room': All admin users
 * - 'security-room': All security staff
 * - 'visitor-{visitorId}': Per-visitor updates
 */
const setupSocketIO = (io) => {
  // Middleware: authenticate socket connections (optional for public events)
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        socket.user = decoded;
      } catch (err) {
        // Non-authenticated socket — public access (visitor registration)
        socket.user = null;
      }
    }
    next();
  });

  io.on('connection', (socket) => {
    console.log(`🔌 Socket connected: ${socket.id} | User: ${socket.user?.email || 'Guest'}`);

    // Join role-based rooms
    if (socket.user) {
      if (socket.user.role === 'admin') {
        socket.join('admin-room');
        console.log(`👑 Admin joined admin-room: ${socket.user.email}`);
      } else if (socket.user.role === 'security') {
        socket.join('security-room');
        console.log(`🛡️ Security joined security-room: ${socket.user.email}`);
      }
    }

    // Visitor tracking room (visitor joins their own room via visitorId)
    socket.on('join-visitor-room', (visitorId) => {
      socket.join(`visitor-${visitorId}`);
      console.log(`👤 Visitor joined room: visitor-${visitorId}`);
    });

    // Security joins the scanning room
    socket.on('join-security-room', () => {
      socket.join('security-room');
    });

    socket.on('disconnect', () => {
      console.log(`🔌 Socket disconnected: ${socket.id}`);
    });
  });
};

/**
 * Emit real-time events from controllers
 */
const emitVisitorUpdate = (io, event, data) => {
  // Notify admin room
  io.to('admin-room').emit(event, data);
  // Notify security room
  io.to('security-room').emit(event, data);
};

const emitToVisitor = (io, visitorId, event, data) => {
  io.to(`visitor-${visitorId}`).emit(event, data);
};

module.exports = { setupSocketIO, emitVisitorUpdate, emitToVisitor };
