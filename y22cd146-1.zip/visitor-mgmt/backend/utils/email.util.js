/**
 * email.util.js - Nodemailer Email Service
 */

const nodemailer = require('nodemailer');

const createTransport = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
    tls: { rejectUnauthorized: false },
  });
};

exports.sendHostNotificationEmail = async (visitor) => {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS ||
      process.env.EMAIL_USER === 'your_email@gmail.com') {
    console.log('⚠️  Email not configured in .env — skipping notification.');
    return false;
  }

  try {
    const transporter = createTransport();
    const entryTime = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    await transporter.sendMail({
      from: `"Visitor Management" <${process.env.EMAIL_USER}>`,
      to: visitor.hostEmail,
      subject: `🔔 Visitor Arrived: ${visitor.name} is here to meet you`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;background:#f8fafc;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;">
          <div style="background:#1a1a2e;color:white;padding:24px;text-align:center;">
            <h1 style="margin:0;font-size:22px;">🏢 Visitor Notification</h1>
            <p style="margin:8px 0 0;color:#94a3b8;font-size:14px;">Smart Visitor Management System</p>
          </div>
          <div style="padding:28px;">
            <p style="font-size:16px;color:#1e293b;margin-bottom:4px;">Hello <strong>${visitor.hostName}</strong>,</p>
            <p style="color:#64748b;margin-bottom:24px;">A visitor has arrived at the reception and is waiting to meet you.</p>
            <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
              <tr style="background:#f1f5f9;"><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;width:35%;">Visitor Name</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;font-weight:500;">${visitor.name}</td></tr>
              <tr><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">Phone</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;">${visitor.phone}</td></tr>
              <tr style="background:#f1f5f9;"><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">Email</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;">${visitor.email}</td></tr>
              <tr><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">Purpose</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;">${visitor.purpose}</td></tr>
              <tr style="background:#f1f5f9;"><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">Arrival Time</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;">${entryTime}</td></tr>
              <tr><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">Group Size</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;">${visitor.numberOfVisitors} person(s)</td></tr>
              ${visitor.vehicleNumber ? `<tr style="background:#f1f5f9;"><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">Vehicle</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;font-family:monospace;">${visitor.vehicleNumber}</td></tr>` : ''}
              ${visitor.idProofType !== 'other' ? `<tr><td style="padding:12px;border:1px solid #e2e8f0;font-weight:600;color:#475569;">ID Proof</td><td style="padding:12px;border:1px solid #e2e8f0;color:#1e293b;text-transform:capitalize;">${visitor.idProofType}</td></tr>` : ''}
            </table>
            <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:14px;margin-bottom:20px;">
              <p style="margin:0;color:#92400e;font-size:14px;">⏳ This visitor is <strong>pending admin approval</strong>. You will be notified once they are approved and allowed entry.</p>
            </div>
            <p style="color:#64748b;font-size:13px;">Please proceed to reception if you wish to meet your visitor.</p>
          </div>
          <div style="background:#f1f5f9;padding:12px;text-align:center;font-size:12px;color:#94a3b8;border-top:1px solid #e2e8f0;">
            Smart Visitor Management System • Auto-generated notification • Do not reply
          </div>
        </div>
      `,
    });

    console.log(`📧 Host notification sent to ${visitor.hostEmail}`);
    return true;
  } catch (err) {
    console.error('❌ Email send failed:', err.message);
    return false;
  }
};
