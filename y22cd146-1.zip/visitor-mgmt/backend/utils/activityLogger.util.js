/**
 * activityLogger.util.js - Centralized Activity Logging
 */

const ActivityLog = require('../models/ActivityLog.model');

/**
 * Log an activity to the database
 * Non-blocking: errors are caught and logged to console without crashing
 */
exports.logActivity = async (params) => {
  try {
    await ActivityLog.create({
      action: params.action,
      description: params.description,
      performedBy: params.performedBy || null,
      performedByName: params.performedByName || 'System',
      visitorId: params.visitorId || null,
      visitorName: params.visitorName || null,
      metadata: params.metadata || {},
      ipAddress: params.ipAddress || null,
      severity: params.severity || 'info',
    });
  } catch (err) {
    console.error('⚠️  Activity log failed:', err.message);
    // Non-fatal - don't throw
  }
};
