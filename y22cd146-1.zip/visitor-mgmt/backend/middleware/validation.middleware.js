/**
 * validation.middleware.js - Input Validation Rules
 */

const { body, param, query, validationResult } = require('express-validator');

/**
 * handleValidation - Checks results and returns errors if any
 */
const handleValidation = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

// ── Visitor Registration Validation ───────────────────────────────────────────
const validateVisitorRegistration = [
  body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
  body('email').trim().isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('phone').trim().notEmpty().withMessage('Phone is required').isLength({ min: 7, max: 20 }),
  body('purpose').trim().notEmpty().withMessage('Purpose is required').isLength({ max: 500 }),
  body('hostName').trim().notEmpty().withMessage('Host name is required'),
  body('hostEmail').optional().isEmail().withMessage('Valid host email required').normalizeEmail(),
  body('numberOfVisitors').optional().isInt({ min: 1, max: 50 }),
  body('hasVehicle').optional().isBoolean(),
  body('vehicleNumber')
    .optional()
    .if(body('hasVehicle').equals(true))
    .notEmpty()
    .withMessage('Vehicle number required when vehicle is selected'),
  handleValidation,
];

// ── Status Update Validation ──────────────────────────────────────────────────
const validateStatusUpdate = [
  param('id').isMongoId().withMessage('Invalid visitor ID'),
  body('status')
    .isIn(['approved', 'rejected', 'inside', 'exited', 'pending'])
    .withMessage('Invalid status value'),
  body('rejectionReason').optional().isString().trim(),
  handleValidation,
];

// ── Auth Validation ───────────────────────────────────────────────────────────
const validateLogin = [
  body('email').trim().isEmail().withMessage('Valid email required').normalizeEmail(),
  body('password').notEmpty().withMessage('Password is required'),
  handleValidation,
];

const validateRegisterUser = [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').trim().isEmail().withMessage('Valid email required').normalizeEmail(),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain uppercase, lowercase, and number'),
  body('role').isIn(['admin', 'security']).withMessage('Role must be admin or security'),
  handleValidation,
];

// ── Query Validation ──────────────────────────────────────────────────────────
const validatePagination = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be 1-100'),
  handleValidation,
];

module.exports = {
  validateVisitorRegistration,
  validateStatusUpdate,
  validateLogin,
  validateRegisterUser,
  validatePagination,
};
