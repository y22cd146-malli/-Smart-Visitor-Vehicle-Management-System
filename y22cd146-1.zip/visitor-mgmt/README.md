# 🏢 Smart Visitor & Vehicle Entry Management System

A production-ready, real-time full-stack application for managing visitor access, vehicle tracking, and security workflows at enterprise facilities.

---

## 📐 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER                             │
│   React.js SPA  ──  React Router  ──  Socket.IO Client          │
│   Axios (REST)  ──  Context API   ──  Chart.js                  │
└───────────────────────────┬─────────────────────────────────────┘
                            │ HTTPS + WSS
┌───────────────────────────▼─────────────────────────────────────┐
│                        API GATEWAY LAYER                        │
│   Express.js  ──  Helmet  ──  CORS  ──  Rate Limiter            │
│   JWT Middleware  ──  Role-Based Access Control                  │
└───────────────────────────┬─────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                      BUSINESS LOGIC LAYER                       │
│   Controllers  ──  Services  ──  Validators                     │
│   Socket.IO Server  ──  Email Service  ──  QR Generator         │
│   Mock AI Vehicle OCR Module                                    │
└───────────────────────────┬─────────────────────────────────────┘
                            │
┌───────────────────────────▼─────────────────────────────────────┐
│                       DATA LAYER                                │
│   MongoDB Atlas (Cloud)  ──  Mongoose ODM                       │
│   Collections: visitors, users, activitylogs                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🗃️ Database Schema (ER Diagram)

```
┌──────────────┐     approvedBy     ┌──────────────┐
│   VISITORS   │ ──────────────────▶│    USERS      │
│──────────────│                    │──────────────│
│ _id          │     rejectedBy     │ _id          │
│ name         │ ──────────────────▶│ name         │
│ email        │                    │ email        │
│ phone        │                    │ password     │
│ purpose      │                    │ role         │
│ hostName     │                    │ department   │
│ hostEmail    │                    │ isActive     │
│ status       │                    │ lastLogin    │
│ qrToken      │                    │ createdAt    │
│ qrCode       │                    └──────────────┘
│ vehicleNumber│                           │
│ entryTime    │                           │ performedBy
│ exitTime     │                           ▼
│ approvedBy──▶│              ┌─────────────────────┐
│ rejectedBy──▶│              │   ACTIVITY_LOGS      │
│ createdAt    │              │─────────────────────│
└──────────────┘              │ _id                  │
        │                     │ action               │
        │ visitorId            │ description          │
        └────────────────────▶│ performedBy          │
                              │ performedByName       │
                              │ visitorId            │
                              │ visitorName          │
                              │ severity             │
                              │ ipAddress            │
                              │ metadata             │
                              │ createdAt (TTL 90d)  │
                              └─────────────────────┘
```

---

## 🌊 Real-Time Data Flow

```
Visitor Registers (QR/Web)
        │
        ▼
Backend: POST /api/visitors/register
        │
        ├──▶ Save to MongoDB
        ├──▶ Generate QR Code (base64)
        ├──▶ Send Email to Host (async)
        ├──▶ Log Activity
        └──▶ io.emit('visitor:new') ──▶ Admin Room
                                    └──▶ Security Room
                                    
Admin/Security Approves
        │
        ▼
Backend: PATCH /api/visitors/:id/status
        │
        ├──▶ Validate status transition
        ├──▶ Update MongoDB
        ├──▶ io.emit('visitor:updated') ──▶ Admin Room
        │                               └──▶ Security Room
        └──▶ io.emit('status:changed') ──▶ visitor-{id} Room
                                         (Visitor's phone updates live)
```

---

## 🔐 Security Architecture

| Layer | Implementation |
|-------|---------------|
| Authentication | JWT (7-day expiry, HS256) |
| Authorization | Role-Based (admin, security) |
| Password | bcryptjs (12 rounds) |
| Rate Limiting | 100 req / 15 min per IP |
| CORS | Whitelist configured via env |
| Headers | Helmet.js security headers |
| Input | express-validator sanitization |
| Password Policy | Uppercase + lowercase + digit |
| Activity Audit | Full action log with IP |
| Token Expiry | JWT changedPasswordAfter check |

---

## 📡 API Documentation

### Authentication
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/auth/login | ❌ | Staff login |
| GET | /api/auth/me | ✅ | Current user |
| PUT | /api/auth/change-password | ✅ | Change password |
| POST | /api/auth/seed-admin | ❌ | Initial admin setup (one-time) |

### Visitors
| Method | Endpoint | Auth | Role | Description |
|--------|----------|------|------|-------------|
| POST | /api/visitors/register | ❌ | Public | Self-registration |
| GET | /api/visitors/verify/:token | ❌ | Public | Get visitor by QR token |
| GET | /api/visitors | ✅ | Admin/Security | List with pagination & filters |
| GET | /api/visitors/export | ✅ | Admin/Security | CSV export |
| GET | /api/visitors/:id | ✅ | Admin/Security | Single visitor |
| PATCH | /api/visitors/:id/status | ✅ | Admin/Security | Update status |
| DELETE | /api/visitors/:id | ✅ | Admin | Delete visitor |
| POST | /api/visitors/scan/qr | ✅ | Admin/Security | Process QR scan |

### Analytics
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | /api/analytics/dashboard | ✅ | Key stats |
| GET | /api/analytics/daily-trend | ✅ | Last N days |
| GET | /api/analytics/monthly-trend | ✅ | Last 12 months |
| GET | /api/analytics/peak-hours | ✅ | Busiest hours |
| GET | /api/analytics/status-distribution | ✅ | Status breakdown |

### Vehicle
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | /api/vehicles/capture | ✅ | AI plate recognition |
| GET | /api/vehicles/search | ✅ | Search by plate |

### Socket.IO Events
| Event | Direction | Payload |
|-------|-----------|---------|
| visitor:new | Server→Client | `{ visitor, message }` |
| visitor:updated | Server→Client | `{ visitor, message }` |
| visitor:deleted | Server→Client | `{ visitorId }` |
| status:changed | Server→Visitor | `{ status, message }` |
| join-visitor-room | Client→Server | `visitorId` |

---

## 🚦 Visitor Status Flow

```
REGISTERED
     │
     ▼
[PENDING] ──── Admin Reviews ───▶ [REJECTED]
     │
     │ Admin Approves
     ▼
[APPROVED] ──── QR Scan / Manual ───▶ [INSIDE] ──── Exit ───▶ [EXITED]
```

---

## 🛠️ Local Development Setup

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (free tier works)
- Git

### Step 1: Clone and Configure Backend

```bash
cd visitor-mgmt/backend
npm install
cp .env.example .env
# Edit .env with your MongoDB URI, JWT secret, email config
```

### Step 2: Seed Initial Admin

```bash
node -e "
const mongoose = require('mongoose');
require('dotenv').config();
mongoose.connect(process.env.MONGODB_URI).then(async () => {
  const res = await fetch('http://localhost:5000/api/auth/seed-admin', { method: 'POST' });
  console.log(await res.json());
  process.exit(0);
});
"
```
Or simply `POST http://localhost:5000/api/auth/seed-admin` once the server is running.

### Step 3: Start Backend

```bash
npm run dev
# Server running on http://localhost:5000
```

### Step 4: Configure and Start Frontend

```bash
cd ../frontend
npm install
cp .env.example .env
# Set REACT_APP_API_URL=http://localhost:5000/api
# Set REACT_APP_SOCKET_URL=http://localhost:5000
npm start
# App running on http://localhost:3000
```

### Default Login
```
Email: admin@visitormanagement.com
Password: Admin@123456
```
⚠️ **Change password immediately after first login!**

---

## 🌐 Deployment Guide

### Backend → Render.com

1. Create account at render.com
2. New → Web Service → Connect GitHub repo
3. Build Command: `npm install`
4. Start Command: `node server.js`
5. Environment Variables:
   ```
   NODE_ENV=production
   MONGODB_URI=<your atlas URI>
   JWT_SECRET=<strong 64-char secret>
   CLIENT_URL=https://your-frontend.vercel.app
   PORT=5000
   EMAIL_USER=your@gmail.com
   EMAIL_PASS=your_app_password
   QR_BASE_URL=https://your-frontend.vercel.app
   ```

### Frontend → Vercel

1. Create account at vercel.com
2. Import GitHub repo → select `frontend` folder as root
3. Build Command: `npm run build`
4. Output Directory: `build`
5. Environment Variables:
   ```
   REACT_APP_API_URL=https://your-backend.onrender.com/api
   REACT_APP_SOCKET_URL=https://your-backend.onrender.com
   REACT_APP_NAME=Smart Visitor Management System
   ```

### MongoDB Atlas Setup

1. Create cluster at cloud.mongodb.com (free M0 tier)
2. Database Access: Create user with read/write permissions
3. Network Access: Allow `0.0.0.0/0` for cloud deployment
4. Get connection string: `mongodb+srv://...`

---

## 📁 Folder Structure

```
visitor-mgmt/
├── backend/
│   ├── config/
│   │   └── socket.config.js     # Socket.IO setup & event emission
│   ├── controllers/
│   │   ├── auth.controller.js   # Login, JWT, seed admin
│   │   ├── visitor.controller.js # Registration, status, QR, CSV
│   │   ├── vehicle.controller.js # AI plate capture, search
│   │   ├── analytics.controller.js # Stats, charts, trends
│   │   ├── activity.controller.js # Audit log retrieval
│   │   └── user.controller.js   # Staff management
│   ├── middleware/
│   │   ├── auth.middleware.js   # JWT protect + role authorize
│   │   ├── error.middleware.js  # Global error handler + asyncHandler
│   │   └── validation.middleware.js # express-validator rules
│   ├── models/
│   │   ├── Visitor.model.js     # Visitor schema + virtuals + indexes
│   │   ├── User.model.js        # Staff schema + bcrypt hooks
│   │   └── ActivityLog.model.js # Audit log + TTL index
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── visitor.routes.js
│   │   ├── vehicle.routes.js
│   │   ├── analytics.routes.js
│   │   ├── activity.routes.js
│   │   └── user.routes.js
│   ├── utils/
│   │   ├── email.util.js        # Nodemailer host notification
│   │   └── activityLogger.util.js # Non-blocking audit logging
│   ├── .env.example
│   ├── package.json
│   └── server.js               # Express + Socket.IO + MongoDB entry
│
└── frontend/
    ├── src/
    │   ├── context/
    │   │   ├── AuthContext.js   # JWT state, login/logout
    │   │   └── SocketContext.js # Socket.IO connection per session
    │   ├── services/
    │   │   └── api.service.js  # Axios instance + all API calls
    │   ├── pages/
    │   │   ├── LoginPage.jsx
    │   │   ├── AdminDashboard.jsx       # Real-time stats + quick actions
    │   │   ├── SecurityDashboard.jsx    # Pending queue + scanner link
    │   │   ├── VisitorListPage.jsx      # Table, filters, export, CRUD
    │   │   ├── VisitorDetailPage.jsx    # Full visitor profile
    │   │   ├── VisitorRegistrationPage.jsx # Public self-registration
    │   │   ├── VisitorStatusPage.jsx    # Public real-time status track
    │   │   ├── QRScanPage.jsx           # Camera scanner + vehicle AI
    │   │   ├── AnalyticsPage.jsx        # Charts and trends
    │   │   ├── ActivityLogPage.jsx      # Audit trail
    │   │   └── UsersPage.jsx            # Staff CRUD
    │   ├── components/
    │   │   └── Common/
    │   │       └── Layout.jsx   # Sidebar, nav, connection indicator
    │   ├── App.js               # Routes, protected routes
    │   ├── index.css            # Global design system
    │   └── index.js
    ├── .env.example
    └── package.json
```

---

## 🔮 Future Enhancements

| Feature | Description |
|---------|-------------|
| **Real AI OCR** | Integrate Google Vision API or AWS Rekognition for actual plate detection |
| **Pre-appointment Booking** | Allow hosts to invite visitors in advance |
| **Multi-site Support** | Multiple facility/gate management |
| **Mobile App** | React Native app for security staff |
| **Biometric Entry** | Face recognition integration |
| **Parking Management** | Slot assignment and availability tracking |
| **WhatsApp Notifications** | Twilio WhatsApp API for host alerts |
| **Blacklist Management** | Flag and block repeat offenders |
| **Badge Printing** | Auto-print visitor badges via thermal printer |
| **Watchlist API** | Third-party background check integration |
| **Offline Mode** | PWA with IndexedDB sync for connectivity gaps |
| **Multi-language** | i18n support for international deployments |

---

## 🐛 Troubleshooting

**Socket.IO not connecting**
- Ensure `CLIENT_URL` in backend `.env` matches frontend URL exactly
- Check CORS configuration in `server.js`

**MongoDB connection fails**
- Whitelist your IP in Atlas Network Access
- Verify connection string format

**Email not sending**
- For Gmail: use App Password, not account password
- Enable 2FA on Gmail first, then generate App Password

**QR Scanner not working**
- Requires HTTPS or localhost (browser camera permission)
- Chrome/Firefox recommended

---

*Built with Node.js, Express, MongoDB Atlas, React, Socket.IO, Chart.js*
