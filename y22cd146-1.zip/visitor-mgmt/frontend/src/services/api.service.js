/**
 * api.service.js - Centralized Axios Instance & API Calls
 */

import axios from 'axios';
import toast from 'react-hot-toast';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

// ── Request Interceptor: Attach JWT ───────────────────────────────────────────
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('vms_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error)
);

// ── Response Interceptor: Handle Errors Globally ──────────────────────────────
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const message = error.response?.data?.message || 'An error occurred';

    if (error.response?.status === 401) {
      localStorage.removeItem('vms_token');
      localStorage.removeItem('vms_user');
      if (!window.location.pathname.includes('/login')) {
        window.location.href = '/login';
      }
    } else if (error.response?.status === 403) {
      toast.error('Access denied. Insufficient permissions.');
    } else if (error.response?.status === 429) {
      toast.error('Too many requests. Please slow down.');
    } else if (error.response?.status >= 500) {
      toast.error('Server error. Please try again later.');
    }

    return Promise.reject({ ...error, message });
  }
);

// ── Auth API ──────────────────────────────────────────────────────────────────
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  getMe: () => api.get('/auth/me'),
  changePassword: (data) => api.put('/auth/change-password', data),
  seedAdmin: () => api.post('/auth/seed-admin'),
};

// ── Visitor API ───────────────────────────────────────────────────────────────
export const visitorAPI = {
  register: (data) => api.post('/visitors/register', data),
  getAll: (params) => api.get('/visitors', { params }),
  getOne: (id) => api.get(`/visitors/${id}`),
  getByToken: (token) => api.get(`/visitors/verify/${token}`),
  updateStatus: (id, data) => api.patch(`/visitors/${id}/status`, data),
  deleteVisitor: (id) => api.delete(`/visitors/${id}`),
  scanQR: (qrToken) => api.post('/visitors/scan/qr', { qrToken }),
  exportCSV: (params) =>
    api.get('/visitors/export', { params, responseType: 'blob' }),
};

// ── Analytics API ─────────────────────────────────────────────────────────────
export const analyticsAPI = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getDailyTrend: (days) => api.get('/analytics/daily-trend', { params: { days } }),
  getMonthlyTrend: () => api.get('/analytics/monthly-trend'),
  getPeakHours: () => api.get('/analytics/peak-hours'),
  getPurposeStats: () => api.get('/analytics/purpose-stats'),
  getStatusDistribution: () => api.get('/analytics/status-distribution'),
};

// ── Vehicle API ───────────────────────────────────────────────────────────────
export const vehicleAPI = {
  capture: (data) => api.post('/vehicles/capture', data),
  search: (plate) => api.get('/vehicles/search', { params: { plate } }),
};

// ── Activity API ──────────────────────────────────────────────────────────────
export const activityAPI = {
  getLogs: (params) => api.get('/activity', { params }),
};

// ── Users API ─────────────────────────────────────────────────────────────────
export const usersAPI = {
  getAll: () => api.get('/users'),
  create: (data) => api.post('/users', data),
  update: (id, data) => api.put(`/users/${id}`, data),
  delete: (id) => api.delete(`/users/${id}`),
};

export default api;
