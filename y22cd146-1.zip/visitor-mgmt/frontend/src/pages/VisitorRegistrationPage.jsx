/**
 * VisitorRegistrationPage.jsx
 * Public form opened via QR scan.
 * Camera-based vehicle plate capture via Python YOLO+OCR server.
 */

import React, { useState, useRef, useCallback } from 'react';
import { visitorAPI } from '../services/api.service';
import toast from 'react-hot-toast';

const OCR_URL = process.env.REACT_APP_OCR_URL || 'http://localhost:8000';

const labelStyle = { display: 'block', fontSize: 13, fontWeight: 500, color: '#94a3b8', marginBottom: 6 };
const inputStyle = { width: '100%', background: '#0f172a', border: '1px solid #334155', borderRadius: 6, padding: '9px 12px', color: '#f1f5f9', fontSize: 14, fontFamily: 'Inter, sans-serif', outline: 'none', boxSizing: 'border-box' };

const VisitorRegistrationPage = () => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [capturedImage, setCapturedImage] = useState(null);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [ocrResults, setOcrResults] = useState([]);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  const [form, setForm] = useState({
    name: '', email: '', phone: '',
    purpose: '', hostName: '', hostEmail: '', hostDepartment: '',
    numberOfVisitors: 1,
    hasVehicle: false, vehicleNumber: '', vehicleType: 'car',
    idProofType: 'other', idProofNumber: '',
  });

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  // ── Camera ──────────────────────────────────────────────────────────────────
  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: 1280, height: 720 }
      });
      streamRef.current = stream;
      setCameraOpen(true);
      setCapturedImage(null);
      setOcrResults([]);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      }, 100);
    } catch {
      toast.error('Camera access denied. Please allow camera permission and try again.');
    }
  };

  const closeCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setCameraOpen(false);
  };

  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    const imageData = canvas.toDataURL('image/jpeg', 0.9);
    setCapturedImage(imageData);
    closeCamera();
    runOCR(imageData);
  }, []);

  const runOCR = async (imageData) => {
    setOcrLoading(true);
    toast('🔍 Reading license plate...', { duration: 3000 });
    try {
      const response = await fetch(`${OCR_URL}/detect-plate-base64`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: imageData }),
      });
      const data = await response.json();
      if (data.success && data.plate_number) {
        update('vehicleNumber', data.plate_number);
        update('hasVehicle', true);
        setOcrResults(data.all_results || []);
        toast.success(`✅ Plate: ${data.plate_number} (${Math.round(data.confidence * 100)}% confidence)`);
      } else {
        toast.error('Could not read plate. Please enter manually or retake photo.');
        setOcrResults([]);
      }
    } catch {
      toast.error('OCR server not reachable. Enter vehicle number manually.');
    } finally {
      setOcrLoading(false);
    }
  };

  // ── Submit ──────────────────────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('Please enter your name'); return; }
    if (!form.email.trim()) { toast.error('Please enter your email'); return; }
    if (!form.phone.trim()) { toast.error('Please enter your phone number'); return; }
    if (!form.purpose.trim()) { toast.error('Please enter purpose of visit'); return; }
    if (!form.hostName.trim()) { toast.error('Please enter host name'); return; }
    if (form.hasVehicle && !form.vehicleNumber.trim()) { toast.error('Please enter or capture vehicle number'); return; }

    setLoading(true);
    try {
      const { data } = await visitorAPI.register({ ...form, registeredVia: 'qr' });
      setResult(data.data);
      setStep(2);
      toast.success('Registration successful!');
    } catch (err) {
      const msg = err.response?.data?.message || err.message || 'Registration failed. Please try again.';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  // ── Success Screen ──────────────────────────────────────────────────────────
  if (step === 2 && result) {
    return (
      <div style={{ minHeight: '100vh', background: '#0f172a', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
        <div style={{ width: '100%', maxWidth: 480, textAlign: 'center' }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
          <h2 style={{ fontSize: 24, fontWeight: 700, color: '#f1f5f9', marginBottom: 8 }}>Registration Successful!</h2>
          <p style={{ color: '#94a3b8', marginBottom: 24 }}>
            Welcome <strong style={{ color: '#f1f5f9' }}>{result.name}</strong>. Pending admin approval.
          </p>
          {result.qrCode && (
            <div style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12, padding: 24, marginBottom: 20 }}>
              <p style={{ fontSize: 14, color: '#94a3b8', marginBottom: 12 }}>Your Visitor QR Code — show this to security</p>
              <img src={result.qrCode} alt="QR" style={{ width: 200, height: 200, borderRadius: 8, background: 'white', padding: 8 }} />
              <p style={{ fontSize: 12, color: '#64748b', marginTop: 8 }}>📸 Screenshot and save this QR code</p>
            </div>
          )}
          <div style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 10, padding: 16, textAlign: 'left', marginBottom: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ color: '#94a3b8', fontSize: 13 }}>Status</span>
              <span style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b', padding: '2px 10px', borderRadius: 100, fontSize: 12, fontWeight: 600 }}>PENDING</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#94a3b8', fontSize: 13 }}>Host notified</span>
              <span style={{ color: '#22c55e', fontSize: 13 }}>📧 Email sent</span>
            </div>
          </div>
          <a href={`/status/${result.visitorId}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: '#3b82f6', color: 'white', padding: '10px 24px', borderRadius: 8, textDecoration: 'none', fontWeight: 500 }}>
            Track My Status →
          </a>
        </div>
      </div>
    );
  }

  // ── Registration Form ───────────────────────────────────────────────────────
  return (
    <div style={{ minHeight: '100vh', background: '#0f172a', padding: '24px 16px' }}>
      <canvas ref={canvasRef} style={{ display: 'none' }} />

      {/* Camera Modal */}
      {cameraOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.97)', zIndex: 1000, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <p style={{ color: '#94a3b8', marginBottom: 12, fontSize: 14, textAlign: 'center' }}>
            📷 Point camera at the <strong style={{ color: '#22c55e' }}>license plate</strong>
          </p>
          <div style={{ position: 'relative', width: '100%', maxWidth: 500 }}>
            <video ref={videoRef} style={{ width: '100%', borderRadius: 12, border: '2px solid #3b82f6', display: 'block' }} playsInline muted />
            {/* Plate guide overlay */}
            <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)', width: '70%', height: 70, border: '3px solid #22c55e', borderRadius: 6, pointerEvents: 'none' }}>
              <span style={{ position: 'absolute', top: -24, left: '50%', transform: 'translateX(-50%)', color: '#22c55e', fontSize: 11, whiteSpace: 'nowrap' }}>Align plate here</span>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 16, marginTop: 24 }}>
            <button onClick={capturePhoto} style={{ background: '#22c55e', color: 'white', border: 'none', borderRadius: 50, width: 72, height: 72, fontSize: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>📸</button>
            <button onClick={closeCamera} style={{ background: '#ef4444', color: 'white', border: 'none', borderRadius: 50, width: 72, height: 72, fontSize: 26, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
          </div>
          <p style={{ color: '#475569', marginTop: 12, fontSize: 12 }}>Tap 📸 to capture • ✕ to cancel</p>
        </div>
      )}

      <div style={{ maxWidth: 580, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>🏢</div>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: '#f1f5f9' }}>Visitor Registration</h1>
          <p style={{ color: '#94a3b8', marginTop: 4, fontSize: 14 }}>Fill in your details to register your visit</p>
        </div>

        <form onSubmit={handleSubmit} style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 12, padding: 28 }}>

          {/* Personal Info */}
          <h3 style={{ color: '#f1f5f9', fontWeight: 600, marginBottom: 16, fontSize: 15, borderBottom: '1px solid #334155', paddingBottom: 8 }}>👤 Personal Information</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div><label style={labelStyle}>Full Name *</label><input style={inputStyle} placeholder="John Doe" value={form.name} onChange={e => update('name', e.target.value)} /></div>
            <div><label style={labelStyle}>Phone Number *</label><input style={inputStyle} placeholder="9876543210" value={form.phone} onChange={e => update('phone', e.target.value)} /></div>
          </div>
          <div style={{ marginTop: 14 }}>
            <label style={labelStyle}>Email Address *</label>
            <input style={inputStyle} type="email" placeholder="john@example.com" value={form.email} onChange={e => update('email', e.target.value)} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
            <div>
              <label style={labelStyle}>ID Proof Type</label>
              <select style={inputStyle} value={form.idProofType} onChange={e => update('idProofType', e.target.value)}>
                <option value="aadhar">Aadhar Card</option>
                <option value="passport">Passport</option>
                <option value="driving_license">Driving License</option>
                <option value="voter_id">Voter ID</option>
                <option value="pan">PAN Card</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div><label style={labelStyle}>ID Number</label><input style={inputStyle} placeholder="XXXX XXXX XXXX" value={form.idProofNumber} onChange={e => update('idProofNumber', e.target.value)} /></div>
          </div>

          {/* Visit Details */}
          <h3 style={{ color: '#f1f5f9', fontWeight: 600, margin: '24px 0 16px', fontSize: 15, borderBottom: '1px solid #334155', paddingBottom: 8 }}>🏢 Visit Details</h3>
          <div>
            <label style={labelStyle}>Purpose of Visit *</label>
            <textarea style={{ ...inputStyle, minHeight: 70, resize: 'vertical' }} placeholder="Business meeting, interview, delivery..." value={form.purpose} onChange={e => update('purpose', e.target.value)} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
            <div><label style={labelStyle}>Host Name *</label><input style={inputStyle} placeholder="Person you are meeting" value={form.hostName} onChange={e => update('hostName', e.target.value)} /></div>
            <div><label style={labelStyle}>Host Department</label><input style={inputStyle} placeholder="HR, IT, Finance..." value={form.hostDepartment} onChange={e => update('hostDepartment', e.target.value)} /></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
            <div><label style={labelStyle}>Host Email (for notification)</label><input style={inputStyle} type="email" placeholder="host@company.com" value={form.hostEmail} onChange={e => update('hostEmail', e.target.value)} /></div>
            <div><label style={labelStyle}>Number of Visitors</label><input style={inputStyle} type="number" min={1} max={50} value={form.numberOfVisitors} onChange={e => update('numberOfVisitors', parseInt(e.target.value))} /></div>
          </div>

          {/* Vehicle with Camera OCR */}
          <h3 style={{ color: '#f1f5f9', fontWeight: 600, margin: '24px 0 16px', fontSize: 15, borderBottom: '1px solid #334155', paddingBottom: 8 }}>🚗 Vehicle Information</h3>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <input type="checkbox" id="hasVehicle" checked={form.hasVehicle} onChange={e => update('hasVehicle', e.target.checked)} style={{ width: 18, height: 18, cursor: 'pointer', accentColor: '#3b82f6' }} />
            <label htmlFor="hasVehicle" style={{ color: '#f1f5f9', fontSize: 14, cursor: 'pointer' }}>I am arriving with a vehicle</label>
          </div>

          {form.hasVehicle && (
            <div>
              {/* AI Capture Box */}
              <div style={{ background: 'rgba(59,130,246,0.08)', border: '1px solid rgba(59,130,246,0.25)', borderRadius: 10, padding: 16, marginBottom: 16 }}>
                <p style={{ color: '#93c5fd', fontWeight: 600, marginBottom: 4, fontSize: 14 }}>🤖 AI Plate Detection (YOLO + OCR)</p>
                <p style={{ color: '#64748b', fontSize: 12, marginBottom: 12 }}>Take a photo of your vehicle's number plate — AI reads it automatically</p>
                <button type="button" onClick={openCamera}
                  style={{ background: '#3b82f6', color: 'white', border: 'none', borderRadius: 8, padding: '9px 16px', cursor: 'pointer', fontSize: 14, fontWeight: 500 }}>
                  📷 Capture Plate Photo
                </button>
                {ocrLoading && <span style={{ marginLeft: 12, color: '#94a3b8', fontSize: 13 }}>⏳ Reading plate...</span>}

                {capturedImage && (
                  <div style={{ marginTop: 12 }}>
                    <img src={capturedImage} alt="Captured" style={{ width: '100%', maxWidth: 280, borderRadius: 8, border: '1px solid #334155', display: 'block' }} />
                    <button type="button" onClick={openCamera} style={{ marginTop: 8, background: 'transparent', border: '1px solid #475569', color: '#94a3b8', borderRadius: 6, padding: '5px 12px', cursor: 'pointer', fontSize: 12 }}>
                      🔄 Retake
                    </button>
                  </div>
                )}

                {ocrResults.length > 1 && (
                  <div style={{ marginTop: 10 }}>
                    <p style={{ color: '#64748b', fontSize: 12, marginBottom: 6 }}>Other candidates (tap to select):</p>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      {ocrResults.slice(1, 4).map((r, i) => (
                        <button key={i} type="button" onClick={() => update('vehicleNumber', r.text)}
                          style={{ background: '#334155', color: '#94a3b8', border: '1px solid #475569', borderRadius: 6, padding: '4px 10px', cursor: 'pointer', fontSize: 12 }}>
                          {r.text} ({Math.round(r.confidence * 100)}%)
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <div>
                  <label style={labelStyle}>Vehicle Number *</label>
                  <input style={{ ...inputStyle, fontFamily: 'monospace', letterSpacing: 2, textTransform: 'uppercase' }}
                    placeholder="MH12AB1234" value={form.vehicleNumber}
                    onChange={e => update('vehicleNumber', e.target.value.toUpperCase())} />
                  <p style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>Auto-filled by AI or enter manually</p>
                </div>
                <div>
                  <label style={labelStyle}>Vehicle Type</label>
                  <select style={inputStyle} value={form.vehicleType} onChange={e => update('vehicleType', e.target.value)}>
                    <option value="car">Car</option>
                    <option value="motorcycle">Motorcycle</option>
                    <option value="truck">Truck</option>
                    <option value="van">Van</option>
                    <option value="bicycle">Bicycle</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          <button type="submit" disabled={loading}
            style={{ width: '100%', background: loading ? '#475569' : '#3b82f6', color: 'white', border: 'none', borderRadius: 8, padding: '13px', fontSize: 15, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer', marginTop: 24 }}>
            {loading ? '⏳ Submitting...' : '✓ Complete Registration'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default VisitorRegistrationPage;
