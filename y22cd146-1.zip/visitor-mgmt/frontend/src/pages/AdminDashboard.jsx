/**
 * AdminDashboard.jsx - Real-Time Admin Overview with QR Code Generator
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import QRCode from 'qrcode';
import { analyticsAPI, visitorAPI } from '../services/api.service';
import { useSocket } from '../context/SocketContext';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

const StatCard = ({ icon, label, value, color, bg }) => (
  <div className="stat-card">
    <div className="stat-icon" style={{ background: bg, color }}>{icon}</div>
    <div>
      <div className="stat-value">{value ?? '—'}</div>
      <div className="stat-label">{label}</div>
    </div>
  </div>
);

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [recentVisitors, setRecentVisitors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [qrCode, setQrCode] = useState(null);
  const [showQR, setShowQR] = useState(false);
  const { socket } = useSocket() || {};

  const registrationURL = `${window.location.origin}/register`;

  const generateQR = useCallback(async () => {
    try {
      const qr = await QRCode.toDataURL(registrationURL, {
        errorCorrectionLevel: 'H',
        type: 'image/png',
        margin: 2,
        width: 300,
        color: { dark: '#1a1a2e', light: '#ffffff' },
      });
      setQrCode(qr);
      setShowQR(true);
    } catch {
      toast.error('Failed to generate QR code');
    }
  }, [registrationURL]);

  const fetchData = useCallback(async () => {
    try {
      const [statsRes, visitorsRes] = await Promise.all([
        analyticsAPI.getDashboard(),
        visitorAPI.getAll({ limit: 8, sortBy: 'createdAt', order: 'desc' }),
      ]);
      setStats(statsRes.data.data);
      setRecentVisitors(visitorsRes.data.data);
    } catch {
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    if (!socket) return;
    const handleNew = ({ visitor, message }) => {
      toast(`👤 ${message}`, { icon: '🔔' });
      setRecentVisitors(prev => [visitor, ...prev.slice(0, 7)]);
      setStats(prev => prev ? { ...prev, totalVisitors: prev.totalVisitors + 1, todayVisitors: prev.todayVisitors + 1, pendingCount: prev.pendingCount + 1 } : prev);
    };
    const handleUpdated = ({ visitor }) => {
      setRecentVisitors(prev => prev.map(v => v._id === visitor._id ? visitor : v));
    };
    socket.on('visitor:new', handleNew);
    socket.on('visitor:updated', handleUpdated);
    return () => { socket.off('visitor:new', handleNew); socket.off('visitor:updated', handleUpdated); };
  }, [socket]);

  const handleApprove = async (id) => {
    try { await visitorAPI.updateStatus(id, { status: 'approved' }); toast.success('Visitor approved'); }
    catch (err) { toast.error(err.message); }
  };

  const handleReject = async (id) => {
    try { await visitorAPI.updateStatus(id, { status: 'rejected', rejectionReason: 'Rejected by admin' }); toast.success('Visitor rejected'); }
    catch (err) { toast.error(err.message); }
  };

  const downloadQR = () => {
    const link = document.createElement('a');
    link.href = qrCode;
    link.download = 'visitor-registration-qr.png';
    link.click();
  };

  if (loading) return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}><div className="spinner" /></div>;

  return (
    <div>
      {/* QR Modal */}
      {showQR && qrCode && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', zIndex: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
          <div style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 16, padding: 32, maxWidth: 420, width: '100%', textAlign: 'center' }}>
            <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 4 }}>📋 Visitor Registration QR</h2>
            <p style={{ color: '#94a3b8', fontSize: 13, marginBottom: 20 }}>Print or display this QR code at your entrance. Visitors scan it to register.</p>
            <div style={{ background: 'white', padding: 16, borderRadius: 12, display: 'inline-block', marginBottom: 16 }}>
              <img src={qrCode} alt="Registration QR" style={{ width: 220, height: 220, display: 'block' }} />
            </div>
            <div style={{ background: '#0f172a', borderRadius: 8, padding: '8px 12px', marginBottom: 20, wordBreak: 'break-all' }}>
              <p style={{ fontSize: 11, color: '#64748b', marginBottom: 2 }}>Registration URL:</p>
              <p style={{ fontSize: 12, color: '#3b82f6' }}>{registrationURL}</p>
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <button onClick={downloadQR} className="btn btn-primary">⬇ Download QR</button>
              <button onClick={() => window.print()} className="btn btn-ghost">🖨 Print</button>
              <button onClick={() => setShowQR(false)} className="btn btn-ghost">✕ Close</button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Admin Dashboard</h1>
          <p className="page-subtitle"><span className="live-dot" style={{ marginRight: 6 }} />Live updates enabled</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={generateQR} className="btn btn-primary">
            📋 Generate Entrance QR
          </button>
          <Link to="/visitors" className="btn btn-ghost btn-sm">View All</Link>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 16, marginBottom: 28 }}>
        <StatCard icon="👥" label="Total Visitors" value={stats?.totalVisitors} color="#3b82f6" bg="rgba(59,130,246,0.15)" />
        <StatCard icon="📅" label="Today" value={stats?.todayVisitors} color="#a855f7" bg="rgba(168,85,247,0.15)" />
        <StatCard icon="📆" label="This Month" value={stats?.monthlyVisitors} color="#f59e0b" bg="rgba(245,158,11,0.15)" />
        <StatCard icon="⏳" label="Pending" value={stats?.pendingCount} color="#ef4444" bg="rgba(239,68,68,0.15)" />
        <StatCard icon="🏢" label="Inside Now" value={stats?.insideCount} color="#22c55e" bg="rgba(34,197,94,0.15)" />
        <StatCard icon="🚪" label="Exited Today" value={stats?.exitedToday} color="#64748b" bg="rgba(100,116,139,0.15)" />
      </div>

      {/* Recent Visitors */}
      <div className="card">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <h2 style={{ fontSize: 16, fontWeight: 600 }}>Recent Visitors</h2>
          <Link to="/visitors" style={{ fontSize: 13, color: 'var(--accent-blue)', textDecoration: 'none' }}>View all →</Link>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Visitor</th><th>Host</th><th>Purpose</th><th>Status</th><th>Registered</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {recentVisitors.length === 0 ? (
                <tr><td colSpan={6} style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 32 }}>No visitors yet</td></tr>
              ) : recentVisitors.map((v) => (
                <tr key={v._id}>
                  <td><div style={{ fontWeight: 500 }}>{v.name}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v.phone}</div></td>
                  <td><div>{v.hostName}</div>{v.hostDepartment && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v.hostDepartment}</div>}</td>
                  <td style={{ maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.purpose}</td>
                  <td><span className={`badge badge-${v.status}`}>{v.status}</span></td>
                  <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{formatDistanceToNow(new Date(v.createdAt), { addSuffix: true })}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      {v.status === 'pending' && <>
                        <button className="btn btn-success btn-sm" onClick={() => handleApprove(v._id)}>✓ Approve</button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleReject(v._id)}>✕ Reject</button>
                      </>}
                      <Link to={`/visitors/${v._id}`} className="btn btn-ghost btn-sm">View</Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
