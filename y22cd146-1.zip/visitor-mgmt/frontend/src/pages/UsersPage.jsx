// UsersPage.jsx - Staff User Management
import React, { useState, useEffect } from 'react';
import { usersAPI } from '../services/api.service';
import toast from 'react-hot-toast';

const defaultForm = { name: '', email: '', password: '', role: 'security', phone: '', department: '', employeeId: '' };

const UsersPage = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(defaultForm);
  const [saving, setSaving] = useState(false);

  const load = () => usersAPI.getAll().then(({ data }) => setUsers(data.data)).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await usersAPI.create(form);
      toast.success('User created');
      setShowForm(false);
      setForm(defaultForm);
      load();
    } catch (err) { toast.error(err.message); }
    finally { setSaving(false); }
  };

  const handleToggleActive = async (user) => {
    try {
      await usersAPI.update(user._id, { isActive: !user.isActive });
      toast.success(user.isActive ? 'User deactivated' : 'User activated');
      load();
    } catch (err) { toast.error(err.message); }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete user ${name}?`)) return;
    try { await usersAPI.delete(id); toast.success('User deleted'); load(); }
    catch (err) { toast.error(err.message); }
  };

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Staff Users</h1><p className="page-subtitle">Manage admin and security accounts</p></div>
        <button className="btn btn-primary" onClick={() => setShowForm(!showForm)}>+ Add User</button>
      </div>

      {showForm && (
        <div className="card" style={{ marginBottom: 20 }}>
          <h3 style={{ marginBottom: 16, fontWeight: 600 }}>New Staff Account</h3>
          <form onSubmit={handleCreate}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 14 }}>
              {[['Name', 'name', 'text', 'Full Name'], ['Email', 'email', 'email', 'user@company.com'], ['Password', 'password', 'password', 'Min 8 chars'], ['Phone', 'phone', 'text', '+91...'], ['Department', 'department', 'text', 'IT, HR...'], ['Employee ID', 'employeeId', 'text', 'EMP001']].map(([label, field, type, ph]) => (
                <div key={field} className="form-group" style={{ margin: 0 }}>
                  <label className="form-label">{label}</label>
                  <input className="form-input" type={type} placeholder={ph}
                    value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })}
                    required={['name', 'email', 'password'].includes(field)} />
                </div>
              ))}
              <div className="form-group" style={{ margin: 0 }}>
                <label className="form-label">Role</label>
                <select className="form-input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                  <option value="security">Security</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
              <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Creating...' : 'Create User'}</button>
              <button type="button" className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div className="card">
        {loading ? <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div> : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Last Login</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u._id}>
                    <td><div style={{ fontWeight: 500 }}>{u.name}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{u.employeeId || ''}</div></td>
                    <td style={{ fontSize: 13 }}>{u.email}</td>
                    <td><span className={`badge badge-${u.role === 'admin' ? 'approved' : 'inside'}`}>{u.role}</span></td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 13 }}>{u.department || '—'}</td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{u.lastLogin ? new Date(u.lastLogin).toLocaleDateString() : 'Never'}</td>
                    <td><span className={`badge badge-${u.isActive ? 'inside' : 'rejected'}`}>{u.isActive ? 'Active' : 'Inactive'}</span></td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => handleToggleActive(u)}>{u.isActive ? 'Deactivate' : 'Activate'}</button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(u._id, u.name)}>🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default UsersPage;
