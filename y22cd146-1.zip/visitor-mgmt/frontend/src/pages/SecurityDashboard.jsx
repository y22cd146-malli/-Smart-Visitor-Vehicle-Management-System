// SecurityDashboard.jsx - Simplified view for security staff
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { visitorAPI, analyticsAPI } from '../services/api.service';
import { useSocket } from '../context/SocketContext';
import toast from 'react-hot-toast';

const SecurityDashboard = () => {
  const [stats, setStats] = useState(null);
  const [pendingVisitors, setPendingVisitors] = useState([]);
  const { socket } = useSocket() || {};

  useEffect(() => {
    const load = async () => {
      const [s, v] = await Promise.all([
        analyticsAPI.getDashboard(),
        visitorAPI.getAll({ status: 'pending', limit: 10 }),
      ]);
      setStats(s.data.data);
      setPendingVisitors(v.data.data);
    };
    load().catch(() => {});
  }, []);

  useEffect(() => {
    if (!socket) return;
    const refresh = async () => {
      const [s, v] = await Promise.all([
        analyticsAPI.getDashboard(),
        visitorAPI.getAll({ status: 'pending', limit: 10 }),
      ]);
      setStats(s.data.data);
      setPendingVisitors(v.data.data);
    };
    socket.on('visitor:new', refresh);
    socket.on('visitor:updated', refresh);
    return () => { socket.off('visitor:new', refresh); socket.off('visitor:updated', refresh); };
  }, [socket]);

  const handleEntry = async (id, name) => {
    try {
      await visitorAPI.updateStatus(id, { status: 'inside' });
      toast.success(`${name} marked as entered`);
    } catch (err) { toast.error(err.message); }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Security Dashboard</h1>
          <p className="page-subtitle"><span className="live-dot" style={{ marginRight: 6 }} />Live monitoring</p>
        </div>
        <Link to="/scan" className="btn btn-primary">📷 Open QR Scanner</Link>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Inside Now', value: stats?.insideCount, color: '#22c55e', bg: 'rgba(34,197,94,0.15)', icon: '🏢' },
          { label: 'Pending', value: stats?.pendingCount, color: '#f59e0b', bg: 'rgba(245,158,11,0.15)', icon: '⏳' },
          { label: 'Today', value: stats?.todayVisitors, color: '#3b82f6', bg: 'rgba(59,130,246,0.15)', icon: '📅' },
        ].map((s) => (
          <div key={s.label} className="stat-card">
            <div className="stat-icon" style={{ background: s.bg, color: s.color }}>{s.icon}</div>
            <div><div className="stat-value">{s.value ?? '—'}</div><div className="stat-label">{s.label}</div></div>
          </div>
        ))}
      </div>

      <div className="card">
        <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 16 }}>⏳ Pending Visitors</h2>
        {pendingVisitors.length === 0 ? (
          <p style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 32 }}>No pending visitors</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Name</th><th>Host</th><th>Purpose</th><th>Actions</th></tr></thead>
              <tbody>
                {pendingVisitors.map((v) => (
                  <tr key={v._id}>
                    <td><div style={{ fontWeight: 500 }}>{v.name}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v.phone}</div></td>
                    <td>{v.hostName}</td>
                    <td style={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.purpose}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button className="btn btn-success btn-sm" onClick={() => handleEntry(v._id, v.name)}>Entry</button>
                        <Link to={`/visitors/${v._id}`} className="btn btn-ghost btn-sm">View</Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default SecurityDashboard;
