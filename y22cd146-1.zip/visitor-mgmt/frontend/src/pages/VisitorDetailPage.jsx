// VisitorDetailPage.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { visitorAPI } from '../services/api.service';
import toast from 'react-hot-toast';

const VisitorDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [visitor, setVisitor] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    visitorAPI.getOne(id).then(({ data }) => {
      setVisitor(data.data);
      setLoading(false);
    }).catch(() => { toast.error('Visitor not found'); navigate('/visitors'); });
  }, [id, navigate]);

  const handleStatus = async (status) => {
    try {
      const { data } = await visitorAPI.updateStatus(id, { status });
      setVisitor(data.data);
      toast.success(`Status updated to ${status}`);
    } catch (err) { toast.error(err.message); }
  };

  if (loading) return <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 80 }}><div className="spinner" /></div>;
  if (!visitor) return null;

  return (
    <div>
      <div className="page-header">
        <div>
          <button className="btn btn-ghost btn-sm" onClick={() => navigate(-1)} style={{ marginBottom: 8 }}>← Back</button>
          <h1 className="page-title">{visitor.name}</h1>
          <p className="page-subtitle"><span className={`badge badge-${visitor.status}`}>{visitor.status}</span></p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {visitor.status === 'pending' && <>
            <button className="btn btn-success" onClick={() => handleStatus('approved')}>✓ Approve</button>
            <button className="btn btn-danger" onClick={() => handleStatus('rejected')}>✕ Reject</button>
          </>}
          {visitor.status === 'approved' && <button className="btn btn-primary" onClick={() => handleStatus('inside')}>Mark Entry</button>}
          {visitor.status === 'inside' && <button className="btn btn-ghost" onClick={() => handleStatus('exited')}>Mark Exit</button>}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        <div className="card">
          <h3 style={{ marginBottom: 14, fontWeight: 600 }}>Personal Info</h3>
          {[['Name', visitor.name], ['Email', visitor.email], ['Phone', visitor.phone], ['ID Type', visitor.idProofType], ['ID Number', visitor.idProofNumber || '—']].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{k}</span>
              <span style={{ fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 14, fontWeight: 600 }}>Visit Details</h3>
          {[['Host', visitor.hostName], ['Department', visitor.hostDepartment || '—'], ['Email', visitor.hostEmail || '—'], ['Purpose', visitor.purpose], ['Group Size', visitor.numberOfVisitors], ['Registered Via', visitor.registeredVia]].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{k}</span>
              <span style={{ fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 14, fontWeight: 600 }}>Time Tracking</h3>
          {[['Registered', new Date(visitor.createdAt).toLocaleString()], ['Entry', visitor.entryTime ? new Date(visitor.entryTime).toLocaleString() : 'Not entered'], ['Exit', visitor.exitTime ? new Date(visitor.exitTime).toLocaleString() : 'Not exited'], ['Duration', visitor.duration || '—']].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{k}</span>
              <span style={{ fontWeight: 500 }}>{v}</span>
            </div>
          ))}
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 14, fontWeight: 600 }}>Vehicle Info</h3>
          {visitor.hasVehicle ? (
            [['Number', visitor.vehicleNumber], ['Type', visitor.vehicleType], ['AI Captured', visitor.vehicleNumberCaptured ? 'Yes' : 'No']].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{k}</span>
                <span style={{ fontWeight: 500 }}>{v}</span>
              </div>
            ))
          ) : <p style={{ color: 'var(--text-muted)' }}>No vehicle registered</p>}
          {visitor.qrCode && (
            <div style={{ marginTop: 16, textAlign: 'center' }}>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 8 }}>Visitor QR Code</p>
              <img src={visitor.qrCode} alt="QR" style={{ width: 120, borderRadius: 8, background: 'white', padding: 4 }} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VisitorDetailPage;
