/**
 * VisitorListPage.jsx - Full Visitor Table with Status Updates & Timestamps
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { visitorAPI } from '../services/api.service';
import { useSocket } from '../context/SocketContext';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

const STATUS_OPTIONS = ['all', 'pending', 'approved', 'inside', 'exited', 'rejected'];

const VisitorListPage = () => {
  const [visitors, setVisitors] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [filters, setFilters] = useState({
    search: '', status: 'all', startDate: '', endDate: '', page: 1, limit: 20,
  });
  const { socket } = useSocket() || {};

  const fetchVisitors = useCallback(async () => {
    setLoading(true);
    try {
      const params = { ...filters };
      if (params.status === 'all') delete params.status;
      if (!params.search) delete params.search;
      const { data } = await visitorAPI.getAll(params);
      setVisitors(data.data);
      setPagination(data.pagination);
    } catch {
      toast.error('Failed to load visitors');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => { fetchVisitors(); }, [fetchVisitors]);

  // Real-time updates
  useEffect(() => {
    if (!socket) return;
    const refresh = () => fetchVisitors();
    socket.on('visitor:new', refresh);
    socket.on('visitor:updated', refresh);
    socket.on('visitor:deleted', refresh);
    return () => {
      socket.off('visitor:new', refresh);
      socket.off('visitor:updated', refresh);
      socket.off('visitor:deleted', refresh);
    };
  }, [socket, fetchVisitors]);

  const handleStatusUpdate = async (id, status, name) => {
    try {
      await visitorAPI.updateStatus(id, { status });
      toast.success(`${name} → ${status}`);
      fetchVisitors(); // Refresh to get updated timestamps
    } catch (err) {
      toast.error(err.response?.data?.message || err.message);
    }
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      const params = {};
      if (filters.status !== 'all') params.status = filters.status;
      if (filters.startDate) params.startDate = filters.startDate;
      if (filters.endDate) params.endDate = filters.endDate;
      const { data } = await visitorAPI.exportCSV(params);
      const url = window.URL.createObjectURL(new Blob([data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `visitors_${Date.now()}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success('CSV exported');
    } catch {
      toast.error('Export failed');
    } finally {
      setExporting(false);
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete visitor record for ${name}?`)) return;
    try {
      await visitorAPI.deleteVisitor(id);
      toast.success('Visitor deleted');
      fetchVisitors();
    } catch (err) {
      toast.error(err.message);
    }
  };

  const formatTime = (dateStr) => {
    if (!dateStr) return '—';
    return format(new Date(dateStr), 'dd/MM/yy hh:mm a');
  };

  const getDuration = (entry, exit) => {
    if (!entry || !exit) return '—';
    const diff = new Date(exit) - new Date(entry);
    const mins = Math.floor(diff / 60000);
    const hrs = Math.floor(mins / 60);
    return hrs > 0 ? `${hrs}h ${mins % 60}m` : `${mins}m`;
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Visitors</h1>
          <p className="page-subtitle">{pagination.total} total records</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={handleExport} disabled={exporting}>
          {exporting ? '⏳' : '⬇'} Export CSV
        </button>
      </div>

      {/* Filters */}
      <div className="card" style={{ marginBottom: 20, display: 'flex', flexWrap: 'wrap', gap: 12 }}>
        <input
          className="form-input"
          style={{ flex: '1 1 200px', width: 'auto' }}
          placeholder="🔍 Search name, email, phone, vehicle..."
          value={filters.search}
          onChange={(e) => setFilters({ ...filters, search: e.target.value, page: 1 })}
        />
        <select
          className="form-input"
          style={{ flex: '0 0 150px', width: 'auto' }}
          value={filters.status}
          onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })}
        >
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>{s === 'all' ? 'All Status' : s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </select>
        <input type="date" className="form-input" style={{ flex: '0 0 160px', width: 'auto' }}
          value={filters.startDate} onChange={(e) => setFilters({ ...filters, startDate: e.target.value, page: 1 })} />
        <input type="date" className="form-input" style={{ flex: '0 0 160px', width: 'auto' }}
          value={filters.endDate} onChange={(e) => setFilters({ ...filters, endDate: e.target.value, page: 1 })} />
        {(filters.search || filters.status !== 'all' || filters.startDate) && (
          <button className="btn btn-ghost btn-sm"
            onClick={() => setFilters({ search: '', status: 'all', startDate: '', endDate: '', page: 1, limit: 20 })}>
            Clear
          </button>
        )}
      </div>

      <div className="card">
        <div className="table-wrap">
          {loading ? (
            <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Visitor</th>
                  <th>Host</th>
                  <th>Vehicle</th>
                  <th>Status</th>
                  <th>Registered</th>
                  <th>Entry Time</th>
                  <th>Exit Time</th>
                  <th>Duration</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {visitors.length === 0 ? (
                  <tr><td colSpan={9} style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No visitors found</td></tr>
                ) : visitors.map((v) => (
                  <tr key={v._id}>
                    <td>
                      <div style={{ fontWeight: 500 }}>{v.name}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v.email}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{v.phone}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 500 }}>{v.hostName}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.purpose}</div>
                    </td>
                    <td>
                      {v.hasVehicle
                        ? <div><div style={{ fontFamily: 'monospace', fontSize: 13, fontWeight: 600 }}>{v.vehicleNumber}</div><div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{v.vehicleType}</div></div>
                        : <span style={{ color: 'var(--text-muted)', fontSize: 13 }}>—</span>}
                    </td>
                    <td><span className={`badge badge-${v.status}`}>{v.status}</span></td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>{formatTime(v.createdAt)}</td>
                    <td style={{ fontSize: 12, color: v.entryTime ? '#22c55e' : 'var(--text-muted)' }}>
                      {formatTime(v.entryTime)}
                    </td>
                    <td style={{ fontSize: 12, color: v.exitTime ? '#94a3b8' : 'var(--text-muted)' }}>
                      {formatTime(v.exitTime)}
                    </td>
                    <td style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                      {getDuration(v.entryTime, v.exitTime)}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                        {v.status === 'pending' && (
                          <>
                            <button className="btn btn-success btn-sm" onClick={() => handleStatusUpdate(v._id, 'approved', v.name)}>✓ Approve</button>
                            <button className="btn btn-danger btn-sm" onClick={() => handleStatusUpdate(v._id, 'rejected', v.name)}>✕ Reject</button>
                          </>
                        )}
                        {v.status === 'approved' && (
                          <button className="btn btn-primary btn-sm" onClick={() => handleStatusUpdate(v._id, 'inside', v.name)}>🚪 Entry</button>
                        )}
                        {v.status === 'inside' && (
                          <button className="btn btn-ghost btn-sm" onClick={() => handleStatusUpdate(v._id, 'exited', v.name)}>🏃 Exit</button>
                        )}
                        <Link to={`/visitors/${v._id}`} className="btn btn-ghost btn-sm">View</Link>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(v._id, v.name)}>🗑</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination */}
        {pagination.pages > 1 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 20 }}>
            <button className="btn btn-ghost btn-sm" disabled={filters.page <= 1}
              onClick={() => setFilters(f => ({ ...f, page: f.page - 1 }))}>← Prev</button>
            <span style={{ padding: '6px 12px', fontSize: 13, color: 'var(--text-secondary)' }}>
              Page {pagination.page} of {pagination.pages}
            </span>
            <button className="btn btn-ghost btn-sm" disabled={filters.page >= pagination.pages}
              onClick={() => setFilters(f => ({ ...f, page: f.page + 1 }))}>Next →</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default VisitorListPage;
