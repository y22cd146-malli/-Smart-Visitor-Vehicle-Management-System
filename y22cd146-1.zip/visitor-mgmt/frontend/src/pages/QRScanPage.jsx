/**
 * QRScanPage.jsx - QR Code Scanner for Security Staff
 */

import React, { useState, useEffect, useRef } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { visitorAPI, vehicleAPI } from '../services/api.service';
import toast from 'react-hot-toast';

const QRScanPage = () => {
  const [scanResult, setScanResult] = useState(null);
  const [manualToken, setManualToken] = useState('');
  const [loading, setLoading] = useState(false);
  const [captureLoading, setCaptureLoading] = useState(false);
  const [mode, setMode] = useState('scan'); // 'scan' | 'manual'
  const scannerRef = useRef(null);
  const scannerInstanceRef = useRef(null);

  useEffect(() => {
    if (mode !== 'scan') return;

    const scanner = new Html5QrcodeScanner(
      'qr-reader',
      { fps: 10, qrbox: { width: 250, height: 250 }, aspectRatio: 1 },
      false
    );

    scanner.render(
      async (decodedText) => {
        scanner.clear();
        await processToken(decodedText);
      },
      (error) => { /* ignore scan errors */ }
    );

    scannerInstanceRef.current = scanner;

    return () => {
      scanner.clear().catch(() => {});
    };
  }, [mode]);  // eslint-disable-line

  const processToken = async (text) => {
    // Extract token from URL if full URL was scanned
    let token = text;
    try {
      const url = new URL(text);
      const parts = url.pathname.split('/');
      token = parts[parts.length - 1];
    } catch {}

    setLoading(true);
    try {
      const { data } = await visitorAPI.scanQR(token);
      setScanResult(data.data);
      toast.success(data.message);
    } catch (err) {
      toast.error(err.message || 'Invalid QR code');
      setScanResult(null);
    } finally {
      setLoading(false);
    }
  };

  const handleManualSearch = async () => {
    if (!manualToken.trim()) return;
    await processToken(manualToken.trim());
  };

  const handleMarkExit = async () => {
    if (!scanResult) return;
    try {
      await visitorAPI.updateStatus(scanResult._id, { status: 'exited' });
      setScanResult((prev) => ({ ...prev, status: 'exited', exitTime: new Date() }));
      toast.success(`${scanResult.name} has exited`);
    } catch (err) {
      toast.error(err.message);
    }
  };

  const handleVehicleCapture = async () => {
    // Mock: simulate camera capture
    setCaptureLoading(true);
    try {
      // In production: capture image from camera feed
      const mockBase64 = 'mock_image_data';
      const { data } = await vehicleAPI.capture({
        imageBase64: mockBase64,
        visitorId: scanResult?._id,
      });
      toast.success(`Vehicle detected: ${data.data.plateNumber} (${(data.data.confidence * 100).toFixed(0)}% confidence)`);
      if (scanResult) {
        setScanResult((prev) => ({ ...prev, vehicleNumber: data.data.plateNumber }));
      }
    } catch (err) {
      toast.error(err.message);
    } finally {
      setCaptureLoading(false);
    }
  };

  const reset = () => {
    setScanResult(null);
    setManualToken('');
    setMode('scan');
  };

  const statusColor = {
    pending: '#f59e0b', approved: '#3b82f6',
    inside: '#22c55e', exited: '#64748b', rejected: '#ef4444',
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">QR Scanner</h1>
          <p className="page-subtitle">Scan visitor QR codes for entry/exit</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            className={`btn btn-sm ${mode === 'scan' ? 'btn-primary' : 'btn-ghost'}`}
            onClick={() => { setScanResult(null); setMode('scan'); }}
          >📷 Camera</button>
          <button
            className={`btn btn-sm ${mode === 'manual' ? 'btn-primary' : 'btn-ghost'}`}
            onClick={() => { setScanResult(null); setMode('manual'); }}
          >⌨️ Manual</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, maxWidth: 900 }}>
        {/* Scanner */}
        <div className="card">
          <h3 style={{ marginBottom: 16, fontSize: 15, fontWeight: 600 }}>
            {mode === 'scan' ? '📷 Camera Scanner' : '⌨️ Manual Entry'}
          </h3>

          {mode === 'scan' && !scanResult && (
            <>
              <div id="qr-reader" ref={scannerRef} />
              <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 12, textAlign: 'center' }}>
                Point camera at visitor's QR code
              </p>
            </>
          )}

          {mode === 'manual' && !scanResult && (
            <div>
              <div className="form-group">
                <label className="form-label">Enter QR Token or Visitor ID</label>
                <input
                  className="form-input"
                  placeholder="Paste token here..."
                  value={manualToken}
                  onChange={(e) => setManualToken(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleManualSearch()}
                />
              </div>
              <button
                className="btn btn-primary"
                onClick={handleManualSearch}
                disabled={loading || !manualToken.trim()}
                style={{ width: '100%', justifyContent: 'center' }}
              >
                {loading ? 'Searching...' : 'Search Visitor'}
              </button>
            </div>
          )}

          {scanResult && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 48, marginBottom: 8 }}>
                {scanResult.status === 'inside' ? '✅' : scanResult.status === 'rejected' ? '❌' : '⚠️'}
              </div>
              <div style={{
                padding: '6px 16px',
                borderRadius: 100,
                background: `${statusColor[scanResult.status]}20`,
                color: statusColor[scanResult.status],
                display: 'inline-block',
                fontWeight: 700,
                textTransform: 'uppercase',
                fontSize: 14,
                marginBottom: 12,
              }}>
                {scanResult.status}
              </div>
              <div style={{ fontWeight: 600, fontSize: 18, marginBottom: 4 }}>{scanResult.name}</div>
              <div style={{ color: 'var(--text-muted)', fontSize: 14 }}>{scanResult.phone}</div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 20 }}>
                {scanResult.status === 'inside' && (
                  <button className="btn btn-ghost" onClick={handleMarkExit} style={{ justifyContent: 'center' }}>
                    🚪 Mark Exit
                  </button>
                )}
                <button className="btn btn-ghost btn-sm" onClick={reset} style={{ justifyContent: 'center' }}>
                  ← Scan Another
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Visitor Details */}
        <div className="card">
          <h3 style={{ marginBottom: 16, fontSize: 15, fontWeight: 600 }}>Visitor Details</h3>

          {!scanResult ? (
            <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>📋</div>
              <p>Scan a QR code to see visitor details</p>
            </div>
          ) : (
            <div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[
                  { label: 'Email', value: scanResult.email },
                  { label: 'Host', value: scanResult.hostName },
                  { label: 'Department', value: scanResult.hostDepartment || '—' },
                  { label: 'Purpose', value: scanResult.purpose },
                  { label: 'Group Size', value: scanResult.numberOfVisitors },
                  { label: 'Entry Time', value: scanResult.entryTime ? new Date(scanResult.entryTime).toLocaleTimeString() : '—' },
                  { label: 'Exit Time', value: scanResult.exitTime ? new Date(scanResult.exitTime).toLocaleTimeString() : '—' },
                  { label: 'Vehicle', value: scanResult.vehicleNumber || 'No vehicle' },
                ].map(({ label, value }) => (
                  <div key={label} style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border)', paddingBottom: 10 }}>
                    <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{label}</span>
                    <span style={{ fontWeight: 500, fontSize: 14 }}>{value}</span>
                  </div>
                ))}
              </div>

              {/* Vehicle AI Capture */}
              <div style={{ marginTop: 16, padding: 12, background: 'rgba(245,158,11,0.08)', borderRadius: 8, border: '1px solid rgba(245,158,11,0.2)' }}>
                <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>🚗 AI Vehicle Capture</p>
                <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 10 }}>
                  Use camera to auto-detect vehicle plate number
                </p>
                <button
                  className="btn btn-sm"
                  style={{ background: 'rgba(245,158,11,0.2)', color: '#f59e0b', border: '1px solid rgba(245,158,11,0.3)' }}
                  onClick={handleVehicleCapture}
                  disabled={captureLoading}
                >
                  {captureLoading ? '⏳ Detecting...' : '📷 Capture Plate'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QRScanPage;
