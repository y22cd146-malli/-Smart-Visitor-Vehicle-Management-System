// ActivityLogPage.jsx
import React, { useState, useEffect } from 'react';
import { activityAPI } from '../services/api.service';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

const severityColor = { info: '#3b82f6', warning: '#f59e0b', error: '#ef4444', critical: '#dc2626' };
const actionIcon = {
  VISITOR_REGISTERED: '📝', VISITOR_APPROVED: '✅', VISITOR_REJECTED: '❌',
  VISITOR_ENTRY: '🚪', VISITOR_EXIT: '🏃', QR_SCANNED: '📷',
  VEHICLE_CAPTURED: '🚗', HOST_NOTIFIED: '📧', USER_LOGIN: '🔑',
  USER_LOGOUT: '🔓', USER_CREATED: '👤', REPORT_DOWNLOADED: '📊',
};

const ActivityLogPage = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    activityAPI.getLogs({ page, limit: 50 })
      .then(({ data }) => { setLogs(data.data); setTotal(data.pagination.total); })
      .catch(() => toast.error('Failed to load logs'))
      .finally(() => setLoading(false));
  }, [page]);

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Activity Logs</h1><p className="page-subtitle">{total} total entries (auto-deleted after 90 days)</p></div>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
        ) : (
          <div>
            {logs.map((log) => (
              <div key={log._id} style={{ display: 'flex', gap: 12, padding: '12px 0', borderBottom: '1px solid var(--border)', alignItems: 'flex-start' }}>
                <div style={{ fontSize: 20, flexShrink: 0 }}>{actionIcon[log.action] || '📌'}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                    <span style={{ fontWeight: 500, fontSize: 14 }}>{log.description}</span>
                    <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 100, background: `${severityColor[log.severity]}20`, color: severityColor[log.severity] }}>
                      {log.severity}
                    </span>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>
                    By {log.performedByName || 'System'} • {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                    {log.ipAddress && ` • IP: ${log.ipAddress}`}
                  </div>
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', flexShrink: 0 }}>
                  {new Date(log.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
            {logs.length === 0 && <p style={{ textAlign: 'center', color: 'var(--text-muted)', padding: 40 }}>No activity logs</p>}
          </div>
        )}

        {Math.ceil(total / 50) > 1 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 20 }}>
            <button className="btn btn-ghost btn-sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
            <span style={{ padding: '6px 12px', fontSize: 13, color: 'var(--text-secondary)' }}>Page {page} of {Math.ceil(total / 50)}</span>
            <button className="btn btn-ghost btn-sm" disabled={page >= Math.ceil(total / 50)} onClick={() => setPage(p => p + 1)}>Next →</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ActivityLogPage;
