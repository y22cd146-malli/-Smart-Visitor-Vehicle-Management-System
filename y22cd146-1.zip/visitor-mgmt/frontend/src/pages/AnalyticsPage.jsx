/**
 * AnalyticsPage.jsx - Charts & Statistics Dashboard
 */

import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, BarElement, LineElement,
  PointElement, ArcElement, Title, Tooltip, Legend, Filler,
} from 'chart.js';
import { Bar, Line, Doughnut } from 'react-chartjs-2';
import { analyticsAPI } from '../services/api.service';
import toast from 'react-hot-toast';

ChartJS.register(
  CategoryScale, LinearScale, BarElement, LineElement,
  PointElement, ArcElement, Title, Tooltip, Legend, Filler
);

const chartDefaults = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { labels: { color: '#94a3b8', font: { size: 12 } } },
  },
  scales: {
    x: { grid: { color: '#334155' }, ticks: { color: '#64748b' } },
    y: { grid: { color: '#334155' }, ticks: { color: '#64748b' } },
  },
};

const AnalyticsPage = () => {
  const [daily, setDaily] = useState([]);
  const [monthly, setMonthly] = useState([]);
  const [peakHours, setPeakHours] = useState([]);
  const [statusDist, setStatusDist] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [d, m, p, s] = await Promise.all([
          analyticsAPI.getDailyTrend(14),
          analyticsAPI.getMonthlyTrend(),
          analyticsAPI.getPeakHours(),
          analyticsAPI.getStatusDistribution(),
        ]);
        setDaily(d.data.data);
        setMonthly(m.data.data);
        setPeakHours(p.data.data);
        setStatusDist(s.data.data);
      } catch {
        toast.error('Failed to load analytics');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}>
      <div className="spinner" />
    </div>
  );

  const dailyChart = {
    labels: daily.map((d) => d.date),
    datasets: [
      {
        label: 'Total Visitors',
        data: daily.map((d) => d.total),
        borderColor: '#3b82f6',
        backgroundColor: 'rgba(59,130,246,0.15)',
        fill: true, tension: 0.4,
      },
      {
        label: 'Approved',
        data: daily.map((d) => d.approved),
        borderColor: '#22c55e',
        backgroundColor: 'rgba(34,197,94,0.1)',
        fill: true, tension: 0.4,
      },
    ],
  };

  const monthlyChart = {
    labels: monthly.map((m) => m.month),
    datasets: [{
      label: 'Monthly Visitors',
      data: monthly.map((m) => m.count),
      backgroundColor: 'rgba(168,85,247,0.7)',
      borderRadius: 6,
    }],
  };

  const peakChart = {
    labels: peakHours.map((h) => h.hour),
    datasets: [{
      label: 'Visitors by Hour',
      data: peakHours.map((h) => h.count),
      backgroundColor: peakHours.map((h) =>
        h.count === Math.max(...peakHours.map((x) => x.count))
          ? '#f59e0b' : 'rgba(59,130,246,0.6)'
      ),
      borderRadius: 4,
    }],
  };

  const statusChart = {
    labels: Object.keys(statusDist).map((s) => s.charAt(0).toUpperCase() + s.slice(1)),
    datasets: [{
      data: Object.values(statusDist),
      backgroundColor: ['#f59e0b', '#3b82f6', '#22c55e', '#64748b', '#ef4444'],
      borderWidth: 0,
    }],
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Analytics</h1>
          <p className="page-subtitle">Visitor trends and insights</p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: 20 }}>
        {/* Daily Trend */}
        <div className="card" style={{ gridColumn: '1/-1' }}>
          <h3 style={{ marginBottom: 16, fontSize: 15, fontWeight: 600 }}>Daily Visitor Trend (Last 14 Days)</h3>
          <div style={{ height: 250 }}>
            <Line data={dailyChart} options={chartDefaults} />
          </div>
        </div>

        {/* Monthly Trend */}
        <div className="card">
          <h3 style={{ marginBottom: 16, fontSize: 15, fontWeight: 600 }}>Monthly Visitors</h3>
          <div style={{ height: 220 }}>
            <Bar data={monthlyChart} options={chartDefaults} />
          </div>
        </div>

        {/* Status Distribution */}
        <div className="card">
          <h3 style={{ marginBottom: 16, fontSize: 15, fontWeight: 600 }}>Status Distribution</h3>
          <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Doughnut
              data={statusChart}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: 'right', labels: { color: '#94a3b8', font: { size: 12 } } },
                },
              }}
            />
          </div>
        </div>

        {/* Peak Hours */}
        <div className="card" style={{ gridColumn: '1/-1' }}>
          <h3 style={{ marginBottom: 4, fontSize: 15, fontWeight: 600 }}>Peak Visit Hours</h3>
          <p style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>
            Yellow bar = busiest hour
          </p>
          <div style={{ height: 200 }}>
            <Bar data={peakChart} options={{
              ...chartDefaults,
              plugins: { legend: { display: false } },
            }} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
