// VisitorStatusPage.jsx - Public status check for visitors
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { visitorAPI } from '../services/api.service';
import { io } from 'socket.io-client';

const statusConfig = {
  pending:  { icon: '⏳', color: '#f59e0b', bg: 'rgba(245,158,11,0.12)', label: 'Pending Approval', message: 'Your registration is under review. Please wait for admin approval.' },
  approved: { icon: '✅', color: '#3b82f6', bg: 'rgba(59,130,246,0.12)',  label: 'Approved',          message: 'Your visit has been approved! Proceed to reception for entry.' },
  inside:   { icon: '🏢', color: '#22c55e', bg: 'rgba(34,197,94,0.12)',   label: 'Inside',           message: 'You are currently inside the premises.' },
  exited:   { icon: '👋', color: '#64748b', bg: 'rgba(100,116,139,0.12)', label: 'Exited',           message: 'Your visit has ended. Thank you!' },
  rejected: { icon: '❌', color: '#ef4444', bg: 'rgba(239,68,68,0.12)',   label: 'Rejected',         message: 'Your visit request has been rejected. Contact the host for more info.' },
};

const VisitorStatusPage = () => {
  const { visitorId } = useParams();
  const [visitor, setVisitor] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    visitorAPI.getByToken(visitorId).then(({ data }) => {
      setVisitor(data.data);
    }).catch(() => {
      // Try by ID
      visitorAPI.getOne(visitorId).then(({ data }) => setVisitor(data.data)).catch(() => {});
    }).finally(() => setLoading(false));
  }, [visitorId]);

  // Subscribe to real-time status updates
  useEffect(() => {
    const SOCKET_URL = process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000';
    const socket = io(SOCKET_URL, { transports: ['websocket', 'polling'] });

    socket.on('connect', () => {
      socket.emit('join-visitor-room', visitorId);
    });

    socket.on('status:changed', ({ status, message }) => {
      setVisitor((prev) => prev ? { ...prev, status } : prev);
    });

    return () => socket.close();
  }, [visitorId]);

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;

  const config = statusConfig[visitor?.status] || statusConfig.pending;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 440 }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 20, fontWeight: 700 }}>🏢 VMS Pro</div>
          <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>Visitor Status Tracker</div>
        </div>

        {!visitor ? (
          <div className="card" style={{ textAlign: 'center', padding: 40 }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>❓</div>
            <h3>Visitor not found</h3>
            <p style={{ color: 'var(--text-muted)', marginTop: 8 }}>Check your QR code and try again.</p>
          </div>
        ) : (
          <>
            <div className="card" style={{ textAlign: 'center', padding: 32, background: config.bg, border: `1px solid ${config.color}30` }}>
              <div style={{ fontSize: 56, marginBottom: 12 }}>{config.icon}</div>
              <div style={{ color: config.color, fontWeight: 700, fontSize: 22, marginBottom: 8 }}>{config.label}</div>
              <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>{config.message}</p>
            </div>

            <div className="card" style={{ marginTop: 16 }}>
              <h3 style={{ marginBottom: 14, fontWeight: 600, fontSize: 15 }}>Your Visit Details</h3>
              {[
                ['Name', visitor.name],
                ['Host', visitor.hostName],
                ['Purpose', visitor.purpose],
                ['Registered', new Date(visitor.createdAt).toLocaleString()],
                ['Entry Time', visitor.entryTime ? new Date(visitor.entryTime).toLocaleString() : '—'],
                ['Exit Time', visitor.exitTime ? new Date(visitor.exitTime).toLocaleString() : '—'],
              ].map(([k, v]) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 14 }}>
                  <span style={{ color: 'var(--text-secondary)' }}>{k}</span>
                  <span style={{ fontWeight: 500 }}>{v}</span>
                </div>
              ))}
            </div>

            <div style={{ textAlign: 'center', marginTop: 16 }}>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-muted)' }}>
                <span className="live-dot" />
                Page auto-updates when your status changes
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default VisitorStatusPage;
