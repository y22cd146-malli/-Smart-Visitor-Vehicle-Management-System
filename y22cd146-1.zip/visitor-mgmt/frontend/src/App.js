/**
 * App.js - Root Component with Routing
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';

// Pages
import LoginPage from './pages/LoginPage';
import AdminDashboard from './pages/AdminDashboard';
import VisitorListPage from './pages/VisitorListPage';
import VisitorDetailPage from './pages/VisitorDetailPage';
import AnalyticsPage from './pages/AnalyticsPage';
import ActivityLogPage from './pages/ActivityLogPage';
import SecurityDashboard from './pages/SecurityDashboard';
import QRScanPage from './pages/QRScanPage';
import VisitorRegistrationPage from './pages/VisitorRegistrationPage';
import VisitorStatusPage from './pages/VisitorStatusPage';
import UsersPage from './pages/UsersPage';
import Layout from './components/Common/Layout';

// ── Protected Route ───────────────────────────────────────────────────────────
const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (allowedRoles && !allowedRoles.includes(user.role)) {
    return <Navigate to="/dashboard" replace />;
  }
  return children;
};

// ── App Routes ─────────────────────────────────────────────────────────────────
const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={user ? <Navigate to="/dashboard" replace /> : <LoginPage />} />
      <Route path="/register" element={<VisitorRegistrationPage />} />
      <Route path="/register/:qrCode" element={<VisitorRegistrationPage />} />
      <Route path="/status/:visitorId" element={<VisitorStatusPage />} />

      {/* Protected Routes */}
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <SocketProvider>
              <Layout />
            </SocketProvider>
          </ProtectedRoute>
        }
      >
        <Route index element={<Navigate to="/dashboard" replace />} />

        {/* Admin Routes */}
        <Route
          path="dashboard"
          element={
            user?.role === 'admin' ? <AdminDashboard /> : <SecurityDashboard />
          }
        />
        <Route
          path="visitors"
          element={<ProtectedRoute allowedRoles={['admin', 'security']}><VisitorListPage /></ProtectedRoute>}
        />
        <Route
          path="visitors/:id"
          element={<ProtectedRoute allowedRoles={['admin', 'security']}><VisitorDetailPage /></ProtectedRoute>}
        />
        <Route
          path="analytics"
          element={<ProtectedRoute allowedRoles={['admin', 'security']}><AnalyticsPage /></ProtectedRoute>}
        />
        <Route
          path="activity"
          element={<ProtectedRoute allowedRoles={['admin']}><ActivityLogPage /></ProtectedRoute>}
        />
        <Route
          path="scan"
          element={<ProtectedRoute allowedRoles={['admin', 'security']}><QRScanPage /></ProtectedRoute>}
        />
        <Route
          path="users"
          element={<ProtectedRoute allowedRoles={['admin']}><UsersPage /></ProtectedRoute>}
        />
      </Route>

      {/* 404 */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App = () => (
  <AuthProvider>
    <Router>
      <AppRoutes />
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: { background: '#1e293b', color: '#f1f5f9', border: '1px solid #334155' },
          success: { iconTheme: { primary: '#22c55e', secondary: '#f1f5f9' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#f1f5f9' } },
        }}
      />
    </Router>
  </AuthProvider>
);

export default App;
