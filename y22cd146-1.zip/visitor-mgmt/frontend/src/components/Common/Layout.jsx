/**
 * Layout.jsx - Sidebar + Main Content Shell
 */

import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useSocket } from '../../context/SocketContext';
import {
  MdDashboard, MdPeople, MdQrCodeScanner, MdBarChart,
  MdHistory, MdAdminPanelSettings, MdLogout, MdMenu, MdClose,
  MdWifi, MdWifiOff,
} from 'react-icons/md';
import toast from 'react-hot-toast';

const Layout = () => {
  const { user, logout, isAdmin } = useAuth();
  const { connected } = useSocket() || {};
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  const navItems = [
    { to: '/dashboard', icon: <MdDashboard />, label: 'Dashboard', roles: ['admin', 'security'] },
    { to: '/visitors', icon: <MdPeople />, label: 'Visitors', roles: ['admin', 'security'] },
    { to: '/scan', icon: <MdQrCodeScanner />, label: 'QR Scanner', roles: ['admin', 'security'] },
    { to: '/analytics', icon: <MdBarChart />, label: 'Analytics', roles: ['admin', 'security'] },
    { to: '/activity', icon: <MdHistory />, label: 'Activity Logs', roles: ['admin'] },
    { to: '/users', icon: <MdAdminPanelSettings />, label: 'Staff Users', roles: ['admin'] },
  ].filter((item) => item.roles.includes(user?.role));

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      {/* Overlay */}
      {sidebarOpen && (
        <div
          style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 40 }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        style={{
          width: 240,
          background: 'var(--bg-secondary)',
          borderRight: '1px solid var(--border)',
          display: 'flex',
          flexDirection: 'column',
          flexShrink: 0,
          transition: 'transform 0.3s',
          position: window.innerWidth < 768 ? 'fixed' : 'relative',
          zIndex: 50,
          height: '100vh',
          transform: window.innerWidth < 768 && !sidebarOpen ? 'translateX(-100%)' : 'translateX(0)',
        }}
      >
        {/* Brand */}
        <div style={{ padding: '20px 16px 16px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: 'var(--accent-blue)', display: 'flex',
              alignItems: 'center', justifyContent: 'center', fontSize: 20,
            }}>🏢</div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>VMS Pro</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Visitor Management</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 8px', overflowY: 'auto' }}>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={() => setSidebarOpen(false)}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '10px 12px',
                borderRadius: 8,
                marginBottom: 2,
                fontSize: 14,
                fontWeight: 500,
                textDecoration: 'none',
                color: isActive ? 'white' : 'var(--text-secondary)',
                background: isActive ? 'var(--accent-blue)' : 'transparent',
                transition: 'all 0.15s',
              })}
            >
              <span style={{ fontSize: 18 }}>{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* User & Logout */}
        <div style={{ padding: '12px 8px', borderTop: '1px solid var(--border)' }}>
          {/* Connection status */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', marginBottom: 8 }}>
            {connected
              ? <><span className="live-dot" /><span style={{ fontSize: 12, color: 'var(--accent-green)' }}>Live</span></>
              : <><MdWifiOff color="var(--accent-red)" /><span style={{ fontSize: 12, color: 'var(--accent-red)' }}>Offline</span></>
            }
          </div>
          <div style={{ padding: '8px 12px', marginBottom: 4 }}>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{user?.name}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{user?.role}</div>
          </div>
          <button
            onClick={handleLogout}
            className="btn btn-ghost"
            style={{ width: '100%', justifyContent: 'flex-start' }}
          >
            <MdLogout /> Logout
          </button>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Mobile Header */}
        <header style={{
          display: 'none',
          alignItems: 'center',
          padding: '12px 16px',
          borderBottom: '1px solid var(--border)',
          background: 'var(--bg-secondary)',
        }}
          className="mobile-header"
        >
          <button onClick={() => setSidebarOpen(true)} className="btn btn-ghost btn-sm">
            <MdMenu size={20} />
          </button>
          <span style={{ fontWeight: 700, marginLeft: 12 }}>VMS Pro</span>
        </header>

        <main style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default Layout;
