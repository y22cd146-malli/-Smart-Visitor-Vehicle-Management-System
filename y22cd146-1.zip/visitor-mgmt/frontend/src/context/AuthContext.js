/**
 * AuthContext.js - Global Authentication State
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authAPI } from '../services/api.service';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('vms_user'));
    } catch {
      return null;
    }
  });
  const [token, setToken] = useState(() => localStorage.getItem('vms_token'));
  const [loading, setLoading] = useState(true);

  // Verify token on mount
  useEffect(() => {
    const verifyToken = async () => {
      if (token) {
        try {
          const { data } = await authAPI.getMe();
          setUser(data.data);
          localStorage.setItem('vms_user', JSON.stringify(data.data));
        } catch {
          logout();
        }
      }
      setLoading(false);
    };
    verifyToken();
  }, []);  // eslint-disable-line

  const login = useCallback(async (credentials) => {
    const { data } = await authAPI.login(credentials);
    setToken(data.token);
    setUser(data.user);
    localStorage.setItem('vms_token', data.token);
    localStorage.setItem('vms_user', JSON.stringify(data.user));
    return data;
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('vms_token');
    localStorage.removeItem('vms_user');
  }, []);

  const isAdmin = user?.role === 'admin';
  const isSecurity = user?.role === 'security';

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout, isAdmin, isSecurity }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
